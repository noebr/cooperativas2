//input con boton
import { faEye } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import{InputGroup,InputGroupAddon,Button,Input}from "reactstrap";;


const InputButton = () => {
    return (
      <React.Fragment>
        
        <InputGroup>
        <Input placeholder="Ver columnas" />
        <InputGroupAddon addonType="append">
          <Button color="secondary"><FontAwesomeIcon icon={faEye}/></Button>
        </InputGroupAddon>
      </InputGroup>
      
          
        
      </React.Fragment>
    );
}
export default InputButton;