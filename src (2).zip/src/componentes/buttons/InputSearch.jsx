//buscar
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import{InputGroup,InputGroupAddon,Button,Input}from "reactstrap";;


const InputSearch = () => {
    return (
      <React.Fragment>
       
        <InputGroup>
        <Input placeholder="Buscar" />
        <InputGroupAddon addonType="append">
          <Button color="secondary"><FontAwesomeIcon icon={faSearch}/></Button>
        </InputGroupAddon>
      </InputGroup>
      
          
       
      </React.Fragment>
    );
}
export default InputSearch;