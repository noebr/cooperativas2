import React from 'react';
import { FormGroup,Input } from "reactstrap";


const SelectInput = () => {
    return (
<React.Fragment>
<FormGroup controlId="exampleForm.ControlSelect2">
<Input type="select"  name="select" id="exampleSelect">
          <option>Filtrar</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
        </Input>
  </FormGroup>
</React.Fragment>
    )
}
export default SelectInput;