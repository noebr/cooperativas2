import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {detailsProduct2} from "../action/ProductActions";
//import Rating from "../components/Rating";
//import { PRODUCT_REVIEW_SAVE_RESET } from "../constants/productConstants";
import { addToCart } from "../action/CartActions";
import { priceNivel } from "../componentes/Util";
import SolidButton from "../componentes/buttons/SolidButton";
import "../App.css";
import {imagenes, metaTags} from '../config/configuraciones'
import { MetaTags } from "react-meta-tags";



function ProductIdHome(props) {
  const [product, setProduct] = useState({});
  // const comment = "";
  // const rating = 0;
  const config_server = JSON.parse(localStorage.getItem("configServer"));
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  let nivel = null;
  if (userInfo) {
    nivel = userInfo.nivel;
  }


  // const { product, loading, error } = productDetails;
 
  //const { success: productSaveSuccess } = productReviewSave;
  const dispatch = useDispatch();
 
  //const {products}
  useEffect(() => {
    // console.log("hola1");
    async function product() {
      const product = await detailsProduct2(props.match.params.id);

      setProduct(product.data.data[0]);
    }
    // async function comments() {
    //   const product = await detailsProduct2(props.match.params.id);

    //   setComments(product.data);
    // }
    product();
    // if (productSaveSuccess) {
    //   swal("Enviado!", "Gracias por tu reseña", "success");
    //   setComment("");
    //   setRating(0);
    //   setId_producto(0);
    //   setId_usuario("");
    // //   dispatch({ type: PRODUCT_REVIEW_SAVE_RESET });
    // } else {
    //  // product();
    // //   comments();
    // } }, [productSaveSuccess, inputRef]);
  }, [props.match.params.id]);

  // const submitHandler = (e) => {
  //   e.preventDefault();

  //   dispatch(
  //     saveProductReview(
  //       comment,
  //       rating,
  //       props.match.params.id,
  //       userInfo.id_cliente
  //     )
  //   );
  // };

  return (
    <div>
      <MetaTags>
    <title>{product.nombre_producto}</title>
    <meta charSet={metaTags.generales.charSet} />
    <link rel="icon" href={metaTags.generales.imgLogo} />
    <meta name="viewport" content={metaTags.generales.imgviewport} />
    <meta name="theme-color" content={metaTags.generales.color} />
    <link rel="apple-touch-icon" href={metaTags.generales.imgLogo}/>
    <link rel="manifest" href={metaTags.generales.manifest} />
  </MetaTags>
      <h1>Producto</h1>
      {!product ? (
        <img src={`${imagenes.urlImage}/errornot.png`} className="img-notfound" alt="productos" />
      ) : (
        <div>
      {product && (
        
        <div>
          <div className="container-pid">
            <main>
              <div className="product-card">
                <img
                  src={`${config_server.urlProducto}/${product.imagen_producto}`}
                  className="cards-id-img"
                  alt={product.nombre_producto}
                />

                <div className="column-cards-id">
                  <div className="fila-card ">
                    <h2 className="titulo-card color-black">
                      {product.nombre_producto}
                    </h2>
                    {userInfo ? (
                        <div className="puntos-details">
                          <div className="price-user">
                            <p className="nivel-user">{userInfo.nivel}:</p>
                            {priceNivel(
                              product.precio_bronce_producto,
                              product.precio_plata_producto,
                              product.precio_oro_producto,
                              product.precio_platino_producto,
                              userInfo.nivel
                            )}{" "}
                            Ptos
                          </div>
                        </div>
                      ) : (
                        <p className="puntos-details">
                        <br />
                        Bronce: {product.precio_bronce_producto} Ptos
                        <br />
                        Plata: {product.precio_plata_producto} Ptos
                        <br />
                        Oro: {product.precio_oro_producto} Ptos
                        <br />
                        Platino: {product.precio_platino_producto} Ptos
                        <br />
                      </p>
                      )}


                  </div>
                  <div className="botones-idproducto">
                    
                    <SolidButton
                      onClick={() => dispatch(addToCart(product,nivel))}
                      txt="Agregar"
                    />
                    {config_server.botonComprarAhora === true ? (
                      <div>
                        {userInfo ? (
                          <Link to="/carrito">
                            <SolidButton
                              type="amarillo-compra"
                              onClick={() => dispatch(addToCart(product,nivel))}
                              txt="Canjear"
                            ></SolidButton>
                          </Link>
                        ) : (
                          <Link to="/signin">
                            <SolidButton
                              type="amarillo-compra"
                              onClick={() => dispatch(addToCart(product,nivel))}
                              txt="Canjear"
                            ></SolidButton>
                          </Link>
                        )}
                      </div>
                    ) : (
                      <br />
                    )}
                  </div>
                </div>
              </div>
              <div>
                <h2 className="centrar">Características destacadas</h2>
                <p className="caracteristicas-t p">{product.desc_producto}</p>
              </div>

              <div className="product-rating">
                {/* <Link
                        className="link-name"
                        to={"#" + products._id}
                        to={`/product/${products._id}`}
                        onClick={() => this.openModal(products)}
                      > {" "}  */}
                {/* <Rating
                          value={product.average_rating}
                          text={product.numreviews + " Reseñas"}
                        /> */}
                {/* </Link> */}
              </div>
            </main>
          </div>
        </div>
      )}
      </div>
      )}

      {/* <h2 className="centrar">
          Tu comentario es muy importante para nosotros
        </h2>
        {userInfo ? (
          <form onSubmit={submitHandler}>
            <div className="datos-forms">
              <input
                ref={inputRef}
                type="hidden"
                id="acticuloId"
                name="articuloId"
                value={userInfo.id_usuario}
                onChange={(e) => setId_usuario(e.target.value)}
              />
              <input
                ref={inputRef}
                type="hidden"
                id="acticuloId"
                name="articuloId"
                value={props.match.params.id}
                onChange={(e) => setId_producto(e.target.value)}
              />

              <select
                ref={inputRef}
                className="filter-comentarios"
                name="rating"
                id="rating"
                value={rating}
                onChange={(e) => setRating(e.target.value)}
              >
                <option value="1">1- Malo</option>
                <option value="2">2- Regular</option>
                <option value="3">3- Bueno</option>
                <option value="4">4- Muy bueno</option>
                <option value="5">5- Excelente</option>
              </select>

              <textarea
                ref={inputRef}
                className="comentarios"
                placeholder="Comentarios"
                rows="8"
                cols="35"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
              ></textarea>

              <button type="submit" className="button-red-forms">
                Enviar
              </button>
            </div>
          </form>
        ) : (
          <div>
            <Link className="login-olvidaste" to="/signin">
              Inicia sesión para dejarnos tu comentario.
            </Link>
          </div>
        )}
        <br />
        <br />
        <h2 className="centrar">Comentarios</h2>
        <br />

        {Object.keys(comments).length == 0 ? (
          <div className="centrar">
            <p>No hay comentarios</p>
          </div>
        ) : (
          comments.data.comments.map((review) => (
            <div className="reviews-name">
              <div key={review._id}>
                <div>
                  <p>{review.name}</p>
                </div>
                <div>
                  <Rating value={review.rating}></Rating>
                </div>
                
                <div>
                  <p>{review.comment}</p>
                </div>
              </div>
            </div>
          ))
        )} */}
    </div>
  );
}
export default ProductIdHome;
