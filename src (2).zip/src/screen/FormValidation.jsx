import React, {useState} from 'react';
import {
    Row,
    Col,
    Button,
    FormGroup,
    Card,
    CardBody,
    CardTitle
} from 'reactstrap';
import { useForm } from 'react-hook-form';
import Form from 'react-validation/build/form';

const FormValidate = () => {
    const { register, handleSubmit,formState: { errors } } = useForm(); 
    const setFormvalue = useState({firstname: "", lastname:"", email:"", age:"", title:"", mobile:"", developer:""});
    const onSubmit = (data) => {
        setFormvalue(data);
    };
        return (
            <Row>
                <Col sm="12">
                    <Card>
                        <CardTitle className="p-3 border-bottom mb-0">
                            <i className="mdi mdi-alert-box mr-2" />
                        Form Validation
                        </CardTitle>
                        <CardBody>
                           
                        <Form onSubmit={handleSubmit(onSubmit)}>
                        <FormGroup>
                            <label className="control-label" htmlFor="firstname">
                                First name *
                            </label>
                            <div className="mb-2">
                                <input
                                   type="text"
                                    
                                   
                                    {...register('firstname', { required: true })}
                                    className="form-control"
                                />
                            </div>
                            {errors.firstname && <span>This field is required</span>}
                        </FormGroup>
                        <FormGroup>
                            <label className="control-label" htmlFor="lastname">
                                Last name *
                            </label>
                            <div className="mb-2">
                                <input
                                    
                                    type="text"
                                   
                                   
                                    {...register('lastname', { required: true })}
                                    className="form-control"
                                />
                            </div>
                            
                            {errors.lastname && <span>This field is required</span>}
                        </FormGroup>
                        <FormGroup>
                            <label className="control-label" htmlFor="username">
                                Username *
                            </label>
                            <div className="mb-2">
                                <input
                                    
                                    type="text"
                                    
                                    
                                    {...register('username', { required: true })}
                                    className="form-control"
                                />
                            </div>
                            {errors.username && <span>This field is required</span>}
                            
                        </FormGroup>
                        <FormGroup>
                            <label className="control-label" htmlFor="email">
                                Email *
                            </label>
                            <div className="mb-2">
                                <input
                                    
                                    type="text"
                                    name="email" 

                                      {...register('email', { required: true,pattern: /^\S+@\S+$/i })}
                                    className="form-control"
                                />
                            </div>
                            {errors.email && <span>This field is required</span>}
                        </FormGroup>
                        <FormGroup>
                            <label className="control-label" htmlFor="mobile">
                                Mobile No *
                            </label>
                            <div className="mb-2">
                                <input
                                    
                                    type="text"
                                  
                                    {...register('mobile', { required: true, maxLength: 11, minLength: 8 })} 
                                    
                                    className="form-control"
                                />
                            </div>
                            {errors.mobile && <span>This field is required</span>}
                        </FormGroup>
                        <FormGroup>
                            <label className="control-label" htmlFor="age">
                                Age *
                            </label>
                            <div className="mb-2">
                                <input
                                    
                                    type="number"
                                    name="age" 
                                    
                                    {...register('age', { required: true, pattern: /\d+/ })}
                                    className="form-control"
                                />
                            </div>
                            
                            {errors.age && <span>Please enter number for age.</span>}
                        </FormGroup>
                        <FormGroup>
                            <label className="control-label" htmlFor="title">
                                Select Gender *
                            </label>
                            <div className="mb-2">
                            <select name="title" className="form-control"  {...register('title', { required: true})}>
                            <option value="">Select Option</option>
                                <option value="Mr">Mr</option>
                                <option value="Mrs">Mrs</option>
                                <option value="Miss">Miss</option>
                                
                            </select>
                            </div>
                            
                            {errors.title && <span>Please select value.</span>}
                        </FormGroup>
                        
                        <FormGroup>
                            <Button className="button btn-info" type="submit">
                                Submit
                            </Button>
                        </FormGroup>
                        </Form> 
                                     
                       
                        </CardBody>
                    </Card>
                </Col>
            </Row>
        );
    }

export default FormValidate;


import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import SolidButton from "../componentes/buttons/SolidButton";
import { register } from "../action/UserActions";
import MetaTags from "react-meta-tags";
import Spinner from "../componentes/Spinner";
import {metaTags} from "../config/configuraciones"

function RegisterHome(props) {
  const [name, setName] = useState("");
  const [last_name, setLast_name] = useState("");
  const [identification, setIdentification] = useState("");
  const [nickname, setNickname] = useState("");
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [repeat_password, setRepeat_password] = useState("");

  const userRegister = useSelector((state) => state.userRegister);
  const { loading, userInfo, error } = userRegister;
  const dispatch = useDispatch();

  const redirect = props.location.search
    ? props.location.search.split("=")[1]
    : "/";
  useEffect(() => {
    if (userInfo) {
      props.history.push(redirect);
    }
    return () => {
      //
    };
  }, [userInfo,props.history,redirect]);

  const submitHandler = (e) => {

    e.preventDefault();
    dispatch(
      register(
        name,
        last_name,
        identification,
        nickname,
        day,
        month,
        year,
        phone,
        email,
        password,
        repeat_password
      )
    );
  };
  return (
    <React.Fragment>

      <h1>Registrarse</h1>
      <form className="container-login-form" onSubmit={submitHandler}>
        <div className="datos-forms">
          {loading && <div><Spinner/></div>}
          {error && <div className="error">{error}</div>}
          <main>
          
         
            <div  className="columna-12">
              
              <label className="label">Nombre</label>
              <input
                className="input"
                type="name"
                name="name"
                id="name"
                onChange={(e) => setName(e.target.value)}
              ></input>

              <label className="label">Apellido</label>
              <input
                className="input"
                type="name"
                name="last_name"
                id="last_name"
                onChange={(e) => setLast_name(e.target.value)}
              ></input>
              <label className="label">Número de cédula</label>
              <input
                className="input"
                type="number"
                name="identification"
                id="identification"
                onChange={(e) => setIdentification(e.target.value)}
              ></input>
              <label className="label">Nickname</label>
              <input
                className="input"
                type="name"
                name="nickname"
                id="nickname"
                onChange={(e) => setNickname(e.target.value)}
              ></input>
              <label className="label">Fecha de Nacimiento</label>
              {/* <div className="fecha-nacimiento"> */}
                <input
                  placeholder="DD"
                  className="input-fecha"
                  type="number"
                  name="day"
                  id="day"
                  onChange={(e) => setDay(e.target.value)}
                ></input>

                <input
                  placeholder="MM"
                  className="input-fecha"
                  type="number"
                  name="month"
                  id="month"
                  onChange={(e) => setMonth(e.target.value)}
                ></input>
                <input
                  placeholder="AAAA"
                  className="input-fecha"
                  type="number"
                  name="year"
                  id="year"
                  onChange={(e) => setYear(e.target.value)}
                ></input>
              </div>
            {/* </div> */}
            <div >
              <label className="label">Teléfono</label>
              <input
                className="input"
                type="tel"
                name="phone"
                id="phone"
                onChange={(e) => setPhone(e.target.value)}
              ></input>

              <label className="label">Correo electrónico</label>
              <input
                className="input"
                type="email"
                name="email"
                id="email"
                onChange={(e) => setEmail(e.target.value)}
              ></input>

              <label className="label">Contraseña</label>
              <input
                className="input"
                type="password"
                id="password"
                name="password"
                onChange={(e) => setPassword(e.target.value)}
              ></input>

              <label className="label">Repetir contraseña</label>
              <input
                className="input"
                type="password"
                id="repeat_password"
                name="repeat_password"
                onChange={(e) => setRepeat_password(e.target.value)}
              ></input>
            
            
          </div>
          
          </main>
          <div className="centrar-botones-r">
            <SolidButton type="secondary" txt="Crear cuenta"></SolidButton>

            <Link
              to={redirect === "/" ? "signin" : "signin?redirect=" + redirect}
              className="login-olvidaste"
            >
              <SolidButton
                type="tertiary"
                txt="¿Ya sos usuario? Iniciar sesión"
              ></SolidButton>
            </Link>
          </div>
        </div>
      </form>
    </React.Fragment>
  );
}
export default RegisterHome;


import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import SolidButton from "../componentes/buttons/SolidButton";
import { register2, signin } from "../action/UserActions";
import MetaTags from "react-meta-tags";
import Spinner from "../componentes/Spinner";
import { metaTags } from "../config/configuraciones";
import {
  Row,
  Col,
  Button,
  FormGroup,
  Card,
  CardBody,
  Label,
  ListGroup,
  ListGroupItem,
  CardTitle,
} from "reactstrap";
import { useForm } from "react-hook-form";
import Form from "react-validation/build/form";

const LoginHome = (props) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const [Formvalue, setFormvalue] = useState({

    identification: "",
    password:"",

  });
  

  const userRegister = useSelector((state) => state.userRegister);
  const { loading, userInfo, error } = userRegister;
  const dispatch = useDispatch();
  const onSubmit = (setFormvalue) => {
    dispatch(signin(setFormvalue));
 
  };
  
  const redirect = props.location.search
    ? props.location.search.split("=")[1]
    : "/";
  useEffect(() => {
    if (userInfo) {
      props.history.push(redirect);
    }
    return () => {
      //
    };
  }, [userInfo, props.history, redirect]);

  return (
    <Row>
      <Col sm="12">
        <Card style={{backgroundColor:"transparent",border:'none'}}>
          <CardTitle className="p-3 border-bottom mb-0">
            <i className="mdi mdi-alert-box mr-2" />
            <h1>Iniciar sesión</h1>
          </CardTitle>
          <CardBody>
          {loading && (
              <div>
                <Spinner />
              </div>
            )}
            {error && <div className="error">{error}</div>}
            <Form onSubmit={handleSubmit(onSubmit)}>

              <FormGroup>
                <div className="mb-2">
                  <input
                    type="text"
                    placeholder="Número de cédula"
                    {...register("identification", { required: true })}
                    className="form-control"
                  />
                </div>

                {errors.identification && <span>Este campo es requerido</span>}
              </FormGroup>


              <FormGroup>
                <div className="mb-2">
                  <input
                    placeholder="Contraseña"
                    type="password"
                    {...register("password", {
                      required: true
                    })}
                    className="form-control"
                  />
                </div>
                {errors.password && <span>Este campo es requerido</span>}
              </FormGroup>
              
              

              <FormGroup>
              <div className="centrar-botones-r">
            <SolidButton type="secondary" txt="Crear cuenta"></SolidButton>

            
          </div>
              </FormGroup>
            </Form>
            <div className="centrar-botones-r">
            <Link
              to={redirect === "/" ? "signin" : "signin?redirect=" + redirect}
              className="login-olvidaste"
            >
              <SolidButton
                type="tertiary"
                txt="¿Ya sos usuario? Iniciar sesión"
              ></SolidButton>
            </Link>
            </div>
          </CardBody>
        </Card>
      </Col>
    </Row>
  );
};


export default LoginHome;


<div className="centrar-botones">
<SolidButton type="secondary" txt="Iniciar sesión"></SolidButton>

<Link
  to={
    redirect === "/"
      ? "register"
      : "register?redirect=" + redirect
  }
>
              <div className="login-olvidaste">

  <p className="link">¿No tenes cuenta?</p>

<SolidButton type="tertiary1" txt="Registrate"></SolidButton>
</div>
  
</Link>
<div className="login-olvidaste2">
<Link to="/codigo">
  <p className="link">¿Olvidaste tu Contraseña?</p>
</Link>
</div>
</div>