import React, { useEffect} from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import SolidButton from "../componentes/buttons/SolidButton";
import { signin } from "../action/UserActions";
import Spinner from "../componentes/Spinner";
import {
  Col,
  FormGroup,
  Card,
  CardBody,
  CardTitle,
} from "reactstrap";
import { useForm } from "react-hook-form";
import Form from "react-validation/build/form";
import {Animated} from "react-animated-css";
const LoginHome = (props) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  // const [Formvalue, setFormvalue] = useState({

  //   identification: "",
  //   password:"",

  // });
  

  const userSignin = useSelector((state) => state.userSignin);
  const { loading, userInfo, error } = userSignin;

  const dispatch = useDispatch();
  const onSubmit = (setFormvalue) => {
    dispatch(signin(setFormvalue));
 
  };
  
  const redirect = props.location.search
    ? props.location.search.split("=")[1]
    : "/";
  useEffect(() => {
    if (userInfo) {
      props.history.push("/");
    }
    return () => {
      //
    };
  }, [userInfo, props.history, redirect]);

  return (
    <Animated animationIn="flipInX" animationOut="flipOutX" animationInDuration={1000} animationOutDuration={1000} isVisible={true}>
    <div className="cuerpo-g-l">
      <div className="cuerpo-login">
      <Col sm="12">
        <Card style={{backgroundColor:"transparent",border:'none'}}>
          <CardTitle>
          
            <h1 className="h1 centrar">Iniciar sesión</h1>
            <div className="centrar-logom">
      <img src="../../fans/logo-menu.png" alt="Emprendimientos virtuales sa" className="logo-menu "/>
      </div>

          </CardTitle>

          <CardBody style={{marginTop:"2rem"}}>
          <div className="requisitos">
          <h2>Requisitos para calificar</h2>
         <p className="p"> • Registrarse a Sólo Fanáticos<br/>
• Ser asociado y estar al día.<br/>
• Asociarse al club.</p>
</div>
          {loading && (
              <div>
                <Spinner />
              </div>
            )}
            {error && <div className="error">{error}</div>}

            <Form onSubmit={handleSubmit(onSubmit)}>


              <FormGroup>
                <div className="mb-2">
                  <input
                    type="text"
                    placeholder="Número de cédula"
                    {...register("identification", { required: true })}
                    className="form-control"
                  />
                </div>

                {errors.identification && <span>Este campo es requerido</span>}
              </FormGroup>


              <FormGroup>
                <div className="mb-2">
                  <input
                    placeholder="Contraseña"
                    type="password"
                    {...register("password", {
                      required: true
                    })}
                    className="form-control"
                  />
                </div>
                {errors.password && <span>Este campo es requerido</span>}
              </FormGroup>
              
              
              <div className="centrar-botones-r">
              <FormGroup>

           
<SolidButton type="secondary" txt="Iniciar sesión"></SolidButton>


          
              </FormGroup>
              </div>
            </Form>
            <div className="centrar-botones">
<Link
  to={
    redirect === "/"
      ? "register"
      : "register?redirect=" + redirect
  }
>
              <div className="login-olvidaste">

  <p className="link">¿No tenes cuenta?</p>

<SolidButton type="tertiary1" txt="Crear cuenta"></SolidButton>
</div>
  
</Link>
<div className="login-olvidaste2">
<Link to="/codigo">
  <p className="link">¿Olvidaste tu Contraseña?</p>
</Link>
</div>
</div>
          </CardBody>
        </Card>
      </Col>
      </div>
      </div>
      </Animated>
  );
};


export default LoginHome;

