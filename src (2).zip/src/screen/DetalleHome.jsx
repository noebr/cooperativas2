import React, { useEffect, useState } from "react";
import { fetchProducts } from "../action/FutbolistaActions";
import { useDispatch, useSelector } from "react-redux";
import Slider from "react-slick";
import { Link } from "react-router-dom";
import {Animated} from "react-animated-css";
import SolidButton from "../componentes/buttons/SolidButton";

function DetalleHome() {
  const config_server = JSON.parse(localStorage.getItem("configServer"));
  const dispatch = useDispatch();
  const calificador = useSelector((state) => state.products);
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;


  const [load, setLoad] = useState(true);

  useEffect(() => {
    if (load) {
      const loadProducts = () => dispatch(fetchProducts());
      loadProducts();
      setLoad(false);
    }
  }, [calificador, dispatch, load]);

  return (
    <React.Fragment>
      <h1>Detalle de autos a calificar</h1>
      <br/>
      {!calificador.items ? (
        <Slider />
      ) : (
        <div>
              
              {calificador.items.formacion.map((formacion) => {
                return (
                  <div
                  >
                   
                   <Animated animationIn="bounceIn" animationInDelay={1500} animationOut="bounce" animationInDuration={2000} animationOutDuration={2000} isVisible={true}>
                      {formacion.imagen_auto === "" ? (
                        <div>
                        <img className="autolist" src="/fans/boy1-sm.png" alt="Emprendimientos virtuales sa" style={{display:"none"}} />
                      
                        {/* <p className={ `nombreju ${opacarTitle}`} style={{display:"none"}}>
                        {formacion.nombre}
                      </p> */}
                      </div>
                        ) : (
                       <div className="autolistde">
                        <img
                        alt="Emprendimientos virtuales sa"
                          className="autolist"
                          
                          src={`${config_server.linkImageAuto}${formacion.imagen_auto}`}
                        />
                                    <p className="p">
                        {formacion.nombre}
                      </p>
                     
          <a href={`${formacion.descripcion_auto}`} target ="_bank">
          <SolidButton type="red-agregar-c" txt="Ver detalle"></SolidButton>
        </a>
                      </div>
                        
                      )}

                    
                    </Animated>
                    
                  </div>
                );
              })}
            </div>
          
        
      )}
    </React.Fragment>
  );
}

export default DetalleHome;
