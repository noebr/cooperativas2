import React, { useEffect, useState} from "react";
import { useSelector, useDispatch } from "react-redux";
import SolidButton from "../componentes/buttons/SolidButton";
import { contacto } from "../action/ProjectActions";
import MetaTags from "react-meta-tags";
import MapGoogle from "../maps/MapGoogle";
import Spinner from "../componentes/Spinner";
import { metaTags } from "../config/configuraciones";

function ContactoHome(props) {
  const [name, setName] = useState("");
  const [last_name, setLast_name] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const config_server = JSON.parse(localStorage.getItem("configServer"));
  

  const userRegisterRepresentante = useSelector(
    (state) => state.userRegisterRepresentante
  );
  const { loading, userInfo, error } = userRegisterRepresentante;
  const dispatch = useDispatch();


  const redirect = props.location.search
    ? props.location.search.split("=")[1]
    : "/";
  useEffect(() => {
    if (userInfo) {
      props.history.push(redirect);
    }
    return () => {
      //
    };
  }, [userInfo,redirect,props.history]);

  const submitHandler = (e) => {
    e.preventDefault();

    dispatch(contacto(name, last_name, email, message));
  };
  
  return (
    <React.Fragment>
      <MetaTags>
        <title>{metaTags.contacto.title}</title>
        <meta
          name="description"
          content={metaTags.contacto.description}

          
        />
        <meta charSet={metaTags.generales.charSet} />
        <link rel="icon" href={metaTags.generales.imgLogo} />
        <meta name="viewport" content={metaTags.generales.imgviewport} />
        <meta name="theme-color" content={metaTags.generales.color} />
        <link rel="apple-touch-icon" href={metaTags.generales.imgLogo}/>
        <link rel="manifest" href={metaTags.generales.manifest} />
      </MetaTags>

      <section>
        <h1>Contacto</h1>
        <div className="contacto-home">
          <div className="container-login-form">
            <form onSubmit={submitHandler}>
              <main>
                <div className="datos-forms-c">
                  {loading && <div><Spinner/></div>}
                  {error && <div className="error">{error}</div>}
                  <br />
                  <br />
                  <input
                    placeholder="Nombre"
                    className="input"
                    type="text"
                    name="name"
                    id="name"
                    onChange={(e) => setName(e.target.value)}
                    required
                  ></input>
                  <input
                    placeholder="Apellido"
                    className="input"
                    type="text"
                    id="last_name"
                    name="last_name"
                    onChange={(e) => setLast_name(e.target.value)}
                  ></input>

                  <input
                    placeholder="Correo electrónico"
                    className="input"
                    type="email"
                    name="email"
                    id="email"
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  ></input>
<main>
                  <textarea
                    className="comentarios"
                    placeholder="Mensaje"
                    rows="8"
                    cols="35"
                    type="text"
                    id="message"
                    name="message"
                    onChange={(e) => setMessage(e.target.value)}
                    required
                  ></textarea>
                  </main>
                </div>
                <div className="boton-contacto">
                  <SolidButton txt="Enviar"></SolidButton>
                </div>
                <br />
                <br />
              </main>
            </form>

          </div>

        </div>
      </section>
    </React.Fragment>
  );
}
export default ContactoHome;
