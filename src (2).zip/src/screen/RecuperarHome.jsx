import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { recuperar } from "../action/UserActions";
import SolidButton from "../componentes/buttons/SolidButton";
import MetaTags from "react-meta-tags";
import Spinner from "../componentes/Spinner";
import {metaTags} from "../config/configuraciones"


function RecuperarHome(props) {
  const [email, setEmail] = useState("");

  const dispatch = useDispatch();

  const redirect = props.location.search
    ? props.location.search.split("=")[1]
    : "/signin";
  const userRecuperar = useSelector((state) => state.userRecuperar);

  const { loading, userInfo, error } = userRecuperar;

  useEffect(() => {
    if (userInfo) {
      props.history.push(redirect);
    }
    return () => {};
  }, [userInfo, props.history, redirect]);

  const submitHandler = (e) => {
    // swal("Revisa tu correo elécctronico!", "Inicia sesión", "success");
    e.preventDefault();
    dispatch(recuperar(email));
  };

  return (
    <React.Fragment>
      <MetaTags>
        <title>{metaTags.recuperarHome.title}</title>
        <meta
          name="description"
          content={metaTags.recuperarHome.description}
        />
        <meta charSet={metaTags.generales.charSet} />
        <link rel="icon" href={metaTags.generales.imgLogo} />
        <meta name="viewport" content={metaTags.generales.imgviewport} />
        <meta name="theme-color" content={metaTags.generales.color} />
        <link rel="apple-touch-icon" href={metaTags.generales.imgLogo}/>
        <link rel="manifest" href={metaTags.generales.manifest} />
      </MetaTags>
      <h1 className="h1 centrar">Restablecer Contraseña</h1>
      <div className="centrar-logom">
      <img src="../../fans/logo-menu.png" alt="Emprendimientos virtuales sa" className="logo-menu "/>
      </div>
      <br/>
      <div className="contra">
      <div className="cuerpo-login">
      <form onSubmit={submitHandler} className="container-login-form">
        
        <p className="p">
          Ingresá tu dirección de correo electrónico asociada con tu cuenta y te
          enviaremos un enlace para restablecer tu contraseña.
        </p>
       <main>
        <div className="container-recuperar-c" style={{marginBottom:"10rem"}}> 
          {loading && <div><Spinner/></div>}
          {error && <div className="error">{error}</div>}
          <div className="centrar-botones-r2">
            <label className="label">Correo eléctronico</label>
            <input
              className="input"
              type="email"
              placeholder="email"
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            
            <SolidButton  txt="Enviar"></SolidButton>
          </div>
          
        </div>
        </main>
      </form>
      </div>
      </div>
    </React.Fragment>
  );
}
export default RecuperarHome;
