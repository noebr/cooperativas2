import { useState } from 'react';

const UseModal = () => {
  const [isShowing, setIsShowing] = useState(false);
  const [url,setUrl] = useState("");

  function toggle(url) {
    setIsShowing(!isShowing);
    setUrl(url);
  
  }

  return {
    isShowing,
    toggle,
    url

    
  }
};

export default UseModal;