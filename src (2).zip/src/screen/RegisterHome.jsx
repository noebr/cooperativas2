import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import SolidButton from "../componentes/buttons/SolidButton";
import { register2 } from "../action/UserActions";
import Spinner from "../componentes/Spinner";
import { countries } from "../assets/tools/paises.json";
import { Col, FormGroup, Card, CardBody, CardTitle } from "reactstrap";
import { useForm } from "react-hook-form";
import Form from "react-validation/build/form";
import { Animated } from "react-animated-css";
import server from "../config/server"


const FormValidate = (props) => {
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  const API = server.baseURL + "register/listSelect";
  const [selects, setSelects] = useState(undefined);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  // const [Formvalue, setFormvalue] = useState({
  //   name: "",
  //   last_name: "",
  //   identification: "",
  //   day: "",
  //   month: "",
  //   year: "",
  //   phone: "",
  //   email: "",
  //   password:"",
  //   repeat_password:""
  // });

  const userRegister = useSelector((state) => state.userRegister);
  const { loading, userInfo, error } = userRegister;
  const dispatch = useDispatch();
  const onSubmit = (setFormvalue) => {
    dispatch(register2(setFormvalue));
  };

  const redirect = props.location.search
    ? props.location.search.split("=")[1]
    : "/";
  useEffect(() => {
    fetch(API, {
      method: "GET"
      // headers: {
      //   Token: `Bearer ${currentUser.data.token}`,
      //   rol: currentUser.data.rol,
      // },
    })
    .then((response) => response.json())
    .then((data) => {
      setSelects(data.data);
    })

    .catch((error) => {
      console.log(error);
    });
    if (userInfo) {
      props.history.push(redirect);
    }
    return () => {
      //
    };
  }, [userInfo, props.history, redirect]);
  console.log("countries",selects);
  return (
    <Animated
      animationIn="flipInX"
      animationOut="flipOutX"
      animationInDuration={1000}
      animationOutDuration={1000}
      isVisible={true}
    >
      <div className="cuerpo-g-l">
        <div className="cuerpo-login">
          <Col sm="12">
            <Card style={{ backgroundColor: "transparent", border: "none" }}>
              <CardTitle>
                <h1 className="h1 centrar">Registrarse</h1>
                <div className="centrar-logom">
                  <img
                    src="../../fans/logo-menu.png"
                    alt="Emprendimientos virtuales sa"
                    className="logo-menu "
                  />
                </div>
              </CardTitle>
              <CardBody style={{ marginTop: "5rem" }}>
                {loading && (
                  <div>
                    <Spinner />
                  </div>
                )}
                {error && <div className="error">{error}</div>}
                <Form onSubmit={handleSubmit(onSubmit)}>
                  <FormGroup>
                    <div className="mb-2">
                      <input
                        type="text"
                        placeholder="Nombre"
                        {...register("name", { required: true })}
                        className="form-control"
                      />
                    </div>
                    {errors.name && <span>Este campo es requerido</span>}
                  </FormGroup>
                  <FormGroup>
                    <div className="mb-2">
                      <input
                        type="text"
                        placeholder="Apellido"
                        {...register("last_name", { required: true })}
                        className="form-control"
                      />
                    </div>

                    {errors.last_name && <span>Este campo es requerido</span>}
                  </FormGroup>
                  <FormGroup>
                <div className="mb-2">
                  <select
                    name="title"
                    className="form-control"
                    {...register("sexo_cliente", { required: true })}
                  >
                    <option value="m" style={{color:"#656667 !important"}}>Masculino</option>
                    <option value="f">Femenino</option>
                  </select>
                </div>

                {errors.sexo_cliente && <span>Por favor, seleccionar</span>}
              </FormGroup>
                  <FormGroup>
                    <div className="mb-2">
                      <input
                        type="text"
                        placeholder="Número de cédula"
                        {...register("identification", { required: true })}
                        className="form-control"
                      />
                    </div>

                    {errors.identification && (
                      <span>Este campo es requerido</span>
                    )}
                  </FormGroup>
                  {/* <FormGroup>
                  <div className="mb-2">
                  <select
                    name="title"
                    className="form-control"
                    {...register("socio_cliente", { required: true })}
                  >
                    <option value="1" style={{color:"#656667 !important"}}>Socio</option>
                    <option value="2">No socio</option>
                    
                  </select>
                </div>

                {errors.socio_cliente && <span>Por favor, seleccionar</span>}
              </FormGroup> */}
                  {/* <FormGroup>
                <div className="mb-2">
                  <input
                    type="text"
                    placeholder="Nickname"
                    {...register("nickname", { required: true })}
                    className="form-control"
                  />
                </div>
                {errors.nickname && <span>Este campo es requerido</span>}
              </FormGroup> */}
                  <FormGroup>
                    <div className="mb-2">
                      <input
                        placeholder="Email"
                        type="text"
                        name="email"
                        {...register("email", {
                          required: true,
                          pattern: /^\S+@\S+$/i,
                        })}
                        className="form-control"
                      />
                    </div>
                    {errors.email && <span>Este campo es requerido</span>}
                  </FormGroup>
                  <label
                    className="control-label"
                    style={{ color: "white", fontSize: "1.4rem" }}
                    htmlFor="mobile"
                  >
                    Fecha de Nacimiento
                  </label>

                  <FormGroup className="row">
                    <input
                      placeholder="DD"
                      className="input-fecha form-control mb-2"
                      type="number"
                      min="1"
                      max="31"
                      {...register("day", { required: true })}
                    ></input>
                    {errors.day && <span>Este campo es requerido</span>}

                    <input
                      placeholder="MM"
                      className="input-fecha form-control mb-2"
                      type="number"
                      min="1"
                      max="12"
                      {...register("month", { required: true })}
                    ></input>
                    {errors.month && <span>Este campo es requerido</span>}
                    <input
                      placeholder="AAAA"
                      className="input-fecha form-control mb-2"
                      type="number"
                      min="1900"
                      max="2005"
                      {...register("year", { required: true })}
                    ></input>
                    {errors.year && <span>Este campo es requerido</span>}
                  </FormGroup>
                  <FormGroup
                    style={{
                      display: "flex",
                      justifyContent: "space-around",
                      flexDirection: "row",
                    }}
                  >
                    <select
                      className="input-tel-se form-control mb-2"
                      {...register("codigo_pais", {
                        required: true,
                      })}
                    >
                      {countries.map((countrie) => {
                        return (
                          <option
                            key={countrie.code}
                            value={countrie.dial_code}
                          >
                            {countrie.name_en} {countrie.dial_code}
                          </option>
                        );
                      })}
                    </select>
                    {errors.codigo_pais && (
                      <span className="text-danger">
                        Este campo es requerido
                      </span>
                    )}
                    <div className="mb-2">
                      <input
                        placeholder="Teléfono"
                        type="number"
                        {...register("phone", {
                          required: true,
                        })}
                        className="form-control"
                      />
                    </div>
                    {errors.phone && (
                      <span>Ingrese celular ejemplo:981111111</span>
                    )}
                  </FormGroup>

                 
                  {!selects ? (
                      <div className="imagen-home-promociones1-oculto"></div>
                    ) : (
                      <FormGroup>
                        <select
                          className="form-control"
                          
                          {...register("id_ciudad", { required: true })}
                        >
                          <option value="">Ciudad</option>
                          {selects.ciudades.map((ciudad) => {
                            return (
                              <option
                                key={ciudad.id_ciudad}
                                value={ciudad.id_ciudad}
                                
                              >
                                {ciudad.nombre_ciudad}
                              </option>
                            );
                          })}
                        </select>
                        
                          
                            {errors.id_ciudad && (
                              <span className="text-danger">
                                Este campo es requerido
                              </span>
                            )}
                          
                        
                          </FormGroup>
                    )}
                                      {!selects ? (
                      <div className="imagen-home-promociones1-oculto"></div>
                    ) : (
                      <FormGroup>
                        <select
                          className="form-control"
                          
                          {...register("id_barrio", { required: true })}
                        >
                          <option value="">Barrio</option>
                          {selects.barrios.map((barrio) => {
                            return (
                              <option
                                key={barrio.id_barrio}
                                value={barrio.id_barrio}
                                
                              >
                                {barrio.nombre_barrio}
                              </option>
                            );
                          })}
                        </select>
                        
                          
                            {errors.id_barrio && (
                              <span className="text-danger">
                                Este campo es requerido
                              </span>
                            )}
                          
                        
                          </FormGroup>
                    )}
                  <FormGroup>
                    <div className="mb-2">
                      <input
                        placeholder="Contraseña"
                        type="password"
                        {...register("password", {
                          required: true,
                        })}
                        className="form-control"
                      />
                    </div>
                    {errors.password && <span>Este campo es requerido</span>}
                  </FormGroup>
                  <FormGroup>
                    <div className="mb-2">
                      <input
                        placeholder="Repetir contraseña"
                        type="password"
                        {...register("repeat_password", {
                          required: true,
                        })}
                        className="form-control"
                      />
                    </div>
                    {errors.repeat_password && (
                      <span>Este campo es requerido</span>
                    )}
                  </FormGroup>

                  <FormGroup>
                    <div className="centrar-botones-r">
                      <SolidButton
                        type="secondary"
                        txt="Crear cuenta"
                      ></SolidButton>
                    </div>
                  </FormGroup>
                </Form>
                <div className="centrar-botones-r">
                  <Link
                    to={
                      redirect === "/"
                        ? "signin"
                        : "signin?redirect=" + redirect
                    }
                    className="login-olvidaste"
                  >
                    <SolidButton
                      type="tertiary"
                      txt="¿Ya sos usuario? Iniciar sesión"
                    ></SolidButton>
                  </Link>
                </div>
              </CardBody>
            </Card>
          </Col>
        </div>
      </div>
    </Animated>
  );
};

export default FormValidate;
