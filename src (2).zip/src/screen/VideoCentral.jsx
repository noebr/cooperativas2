import React from "react";
import ReactPlayer from "react-player";
import "../App.css";
import video from "../assets/videos/autos.mp4"


function VideoCentral() {

  return (
    <div >

<h1 className="h1 centrar">¿Cómo puedo calificar?</h1>
<div className="app-video">
                  <div className="video-contenidos">

                    <div className="container-title-tutorial">
                    
                    </div>
                    <ReactPlayer
                      loading="lazy"
                      width="100%"
                      height="100%"
                    url={video}
                    //   light={config_server.urlVideos + videos.image}
                      // url={"./videos/" + videos.url}
                      controls
                    />
                  </div>
                </div>
              
        </div>
                
      
    
  );
}

export default VideoCentral;
