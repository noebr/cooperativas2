import React, { useEffect, useState } from "react";
import { useDispatch, useSelector} from "react-redux";
import { CardBody,Progress, Spinner } from "reactstrap";
import clienteAxios from "../config/axios";
import server from "../config/server";



function CalificacionesClientesTodos(props) {
  const API = server.baseURL + "calautos/getCalificacionCliente/";
  const [calificaciones, setCalificaciones] = useState([]);
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const config_server = JSON.parse(localStorage.getItem("configServer"));

  const dispatch = useDispatch();


  useEffect(() => {
    async function calificaciones() {
      const { data } = await clienteAxios.get(`calautos/votaciones/listEncuentro`
      );
      setCalificaciones(data.data);
    }
     calificaciones();

  }, [dispatch, userInfo]);


  const renderCalificacion = (obj) => {
    return obj.map((cal) => {
        console.log("calificacion",obj)
      const calificacion = parseInt(cal.promedio);
      const porcentaje = parseInt(cal.porcentaje);
      const auto = cal.nombre_auto + ' ' + cal.apellido_auto ;
      const imagen = cal.imagen_auto !== "" ? cal.imagen_auto : "/fans/boy1-sm.png" ;
      const puntos = cal.votos;
      const participantes = cal.cantidad;
      const id = cal.id_auto
      let color = "";

      switch (true) {
        case porcentaje >= 0 && porcentaje <= 49:
          color = 'warning';
          break;
        case porcentaje >= 50 && porcentaje <= 79:
          color = 'primary';
          break;
        case porcentaje >= 80 && porcentaje <= 100:
          color = 'success';
          break;
      }

      return (
          
        <li className="mb-4" key= {id}>
        <div className="d-flex align-items-center" >
          <small style={{display:"flex",flexDirection:"row"}}>
            <div style={{display:"flex",alignItems:"center"}}>
            <img className="camiseta" src={`${config_server.linkImageauto}${imagen}`} alt={auto}/>
            </div>
            <div>
            <h2 className="color-white">{auto}</h2>
            <h5 style={{color:"white", marginLeft:"1rem"}}>Puntos: {puntos} - Participantes: {participantes}</h5>
            </div>
          </small>
         
          <div className="ml-auto">
            <h2 className="h1-1">{calificacion}</h2>
          </div>
        </div>

        <Progress value={porcentaje} color={color}></Progress>
      </li>
      );
    });
  };
  const fecha_encuentro = (obj) => {
    return obj.map((cal) => {
        console.log("encuentro",obj) 
      const dia = cal.dia_encuentro
      const hora = cal.hora_encuentro
      const torneo = cal.nombre_torneo
      const fecha = cal.fecha_encuentro
      const lista = cal.calificacion
      if(lista.length > 0){
        return (
            <div className="container-azul2">
            <div className="cab-verde3">
            
              <h2>{torneo} - {fecha}<br/>{dia} {hora} </h2>
            </div>
            <div className="container-azul-todos">
            <CardBody >
            <ul className="list-style-none country-state mt-4" style={{marginLeft:"-4rem"}}>
            {renderCalificacion(lista)}
            </ul>
            </CardBody>
          </div>
            </div>   
            );
      }

     
    });
  };
 

  return (
    <React.Fragment>
      <section className="container-gr">
       


            
               
                  
                  {calificaciones.length === 0 ? (
                    <Spinner/>
                  ) : (
                    <div><br/>
{fecha_encuentro(calificaciones)}
                      
                    </div>
                  )} 
                 
                
             

      
      </section>
    </React.Fragment>
  );
}
export default CalificacionesClientesTodos;
