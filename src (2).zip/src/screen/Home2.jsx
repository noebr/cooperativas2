import React, { useEffect, useState } from "react";
import Formacion1 from "../alineaciones/Formacion1";
import Slider from "react-slick";
import { fetchAuspiciantes } from "../action/AuspicianteActions";
import { fetchAuspiciantes2 } from "../action/AuspicianteActions2";
import "../App.css";
import GraficosVotaciones from "../componentes.home/GraficosVotaciones";
import SolidButton from "../componentes/buttons/SolidButton";
import ContactoHome2 from "./ContactoHome2";
import { useDispatch, useSelector } from "react-redux";
import TablaComponent from "../componentes.home/TablaComponent";
import { Link } from "react-router-dom";
import { Auspiciantes } from "../componentes.home/Auspiciantes";

function Home2() {
  const [load1, setLoad1] = useState(true);
  const [load2, setLoad2] = useState(true);
  const config_server = JSON.parse(localStorage.getItem("configServer"));
  const dispatch = useDispatch();
  const auspiciantes = useSelector((state) => state.auspiciantes);
  const auspiciantes2 = useSelector((state) => state.auspiciantes2);
  const encuentros = useSelector((state) => state.products);

  useEffect(() => {
    if (load1) {
      const loadAuspiciantes = () => dispatch(fetchAuspiciantes());
      loadAuspiciantes();
      setLoad1(false);
    }
    if (load2) {
      const loadAuspiciantes2 = () => dispatch(fetchAuspiciantes2());
      loadAuspiciantes2();
      setLoad2(false);
    }
  }, [auspiciantes, dispatch, load1, load2]);
  const config = {
    dots: false,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: -3,
    cssEase: "linear",
    arrows: false,
    autoplay: true,
    speed: 1000,
    autoplaySpeed: 2000,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: -3,
          infinite: true,
          dots: false,
          autoplay: true,
          speed: 1000,
          autoplaySpeed: 2000,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: -3,
          infinite: true,
          dots: false,
          autoplay: true,
          speed: 1000,
          autoplaySpeed: 2000,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 3,
          slidesToScroll: -3,
          infinite: true,
          dots: false,
          autoplay: true,
          speed: 1000,
          autoplaySpeed: 2000,
        },
      },
    ],
  };
  const config2 = {
    dots: false,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 3,
    cssEase: "linear",
    arrows: false,
    autoplay: true,
    speed: 1000,
    autoplaySpeed: 2000,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: false,
          autoplay: true,
          speed: 1000,
          autoplaySpeed: 2000,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: false,
          autoplay: true,
          speed: 1000,
          autoplaySpeed: 2000,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: false,
          autoplay: true,
          speed: 1000,
          autoplaySpeed: 2000,
        },
      },
    ],
  };
  const graficos = () => {
    return (
      <div className="graficos">
        <GraficosVotaciones />
      </div>
    );
  };
  const settings2 = config2;
  const settings = config;
  console.log("ffff", encuentros.items);
  return (
    <React.Fragment>
      <br />
      <Auspiciantes />
      <TablaComponent />

      <h1 className="h3 centrar" style={{ marginTop: "3.5rem !important" }}>
        Califica al vehículo que será sorteado entre socios y suscriptores.
      </h1>

      <div id="califica">
        <Formacion1 />
      </div>

      <div className="comocalificarf">
        <div className="cfff">
          <h1 className="preg">Ver autos a calificar</h1>

          <Link to="/detalle-autos">
            <SolidButton type="red-agregar-c" txt="Ingresa aquí"></SolidButton>
          </Link>
        </div>
      </div>

      <div id="graficos">
        {!auspiciantes.items ? (
          <div className="imagen-home-promociones1-oculto"></div>
        ) : (
          <Slider
            {...settings2}
            aria-hidden="true"
            style={{ marginTop: "5rem", marginBottom: "2rem" }}
          >
            {auspiciantes.items.map((auspiciante) => {
              return (
                <img
                  key={auspiciante.id_auspiciante}
                  src={`${config_server.linkImageAuspiciante}${auspiciante.imagen_auspiciante}`}
                  className="img-auspiciantes"
                  alt="Emprendimientos virtuales sa"
                />
              );
            })}
          </Slider>
        )}
        {!auspiciantes2.items ? (
          <div className="imagen-home-promociones1-oculto"></div>
        ) : (
          <Slider
            {...settings}
            aria-hidden="true"
            // style={{ marginTop: "2rem", marginBottom: "25rem" }}
          >
            {auspiciantes2.items.map((auspiciante) => {
              return (
                <img
                  key={auspiciante.id_auspiciante}
                  src={`${config_server.linkImageAuspiciante}${auspiciante.imagen_auspiciante}`}
                  className="img-auspiciantes"
                  alt="Emprendimientos virtuales sa"
                />
              );
            })}
          </Slider>
        )}

        <br />
        <br />
      </div>
      {graficos()}

      <br />
      <br />

      <br />
      <div>
        <div id="contacto">
          <ContactoHome2 />
        </div>
      </div>
    </React.Fragment>
  );
}

export default Home2;
