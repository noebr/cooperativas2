import React from "react";
import { Link } from "react-router-dom";



const Notfound = () => (
  <div className="container-notf">
    <img
      src="../../fans/error404.png"
      className="img-notfound"
      alt="Error"
    />
    <Link className="link-notfound link-naranja" to="/">
      Volver al Inicio ¡Click aquí!
    </Link>
    <br/><br/><br/><br/>
  </div>
);
export default Notfound;
