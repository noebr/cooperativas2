import React from "react";
import {imagenes} from '../config/configuraciones'


const Error = ({ children }) => {
  return (
    <div className="container-notf">
      <img src={`${imagenes.urlImage}/errornotfound.png`} className="img-notfound" alt="productos" />
      <div className="main-container">
          {children}
          </div>
    </div>
  );
};
export default Error;
