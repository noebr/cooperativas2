import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import SolidButton from "../componentes/buttons/SolidButton";
import { enviarVotaciones } from "../action/VotacionActions";
import { fetchProducts } from "../action/FutbolistaActions";
import { fetchAuspiciantes3 } from "../action/AuspicianteActions3";
import swal from "sweetalert";
import { Link } from "@material-ui/core";
import { NavLink, useHistory } from "react-router-dom";
import Button from 'react-bootstrap/Button'

function JugadorId({ match }) {
  const config_server = JSON.parse(localStorage.getItem("configServer"));
  const [calificacion_votacion, setCalificacion_votacion] = useState("");
  const [isLoading, setLoading] = useState(false);
  const setId_auto = useState("");
  const [load, setLoad] = useState(true);
  const [load3, setLoad3] = useState(true);
  const usuario = JSON.parse(localStorage.getItem("userInfo"));
  const { id } = match.params;
  const { nombre } = match.params;
  const { imagen } = match.params;
  const calificador = useSelector((state) => state.products);
  const auspiciantes3 = useSelector((state) => state.auspiciantes3);
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const history = useHistory() ;
  const goBack = () => {
    history.goBack()
  }

  const dispatch = useDispatch();

  useEffect(() => {
    if (load3) {
      const loadAuspiciantes3 = () => dispatch(fetchAuspiciantes3());
      loadAuspiciantes3();
      setLoad3(false);
    }
    if (!userInfo) {
      swal({
        title: "Iniciá sesión para continuar",
        text: "Para poder calificar debes iniciar sesión",
        dangerMode: true,
        button: "iniciar sesión",
        closeModal: true,
      }).then((willDelete) => {
        if (willDelete) {
          window.location.replace("/signin");
        }
      });
    } else {
      if (load) {
        const loadProducts = () => dispatch(fetchProducts());
        loadProducts();
        setLoad(false);
      }
    }
  }, []);

  const submitHandler = (e) => {
    if (calificacion_votacion == ""){
    
      swal({
       title: "¡Ups!",
       text: "Marca tu calificación",
       dangerMode: true,
       button: "ok",
       closeModal: true,
     }).then((willDelete) => {
       if (willDelete) {
 
       }
     });
     }else{
   
    e.preventDefault();
    setLoading(true);
    dispatch(
      enviarVotaciones(
        calificador.items.calificador.id_calificador,
        calificador.items.tipo_formacion,
        usuario.id_cliente,
        calificacion_votacion,
        id
        )
      );
    }

  };
  // const estadoActual =calificador.filteredItems.calificador.estado_actual_calificador
  console.log(calificador);
  const RenderCalificador = () => {
    return (
      <div className="container-azul233">
        <div className="cab-verde-jugadorid">
          <h1 className="h1-1 centrar">Calificá</h1>
        </div>
        <br />
        <div className="container-azul">
        
          <div className="centrar">
            <img
              alt="Emprendimientos virtuales sa"
              className="jugadorid"
              src={`${config_server.linkImageAuto}${imagen}`}
            />
          </div>

          {/* <div className="centrar">
            <p className="nombre-jugadorid">{nombre}</p>
          </div> */}
          
          <h2 className="centrar" style={{ textAlign: "center" }}>
            El 10 es la calificación más alta.
          </h2>
          <br/>
          <Link href="https://www.kia.com.pe/pdf/catalogos/rio.pdf" target="_blank">
          <h3 className="centrar text-white" style={{ textAlign: "center" }}>
             Ver detalle de Auto a Votar.
          </h3>
          </Link>
          <form onSubmit={submitHandler}>
            {/* {!calificador.items ? (
                <div></div>
              ) : (
                <div>
                   <input type="hidden" value={calificador.items.calificador.id_calificador} onChange={(e) => setId_calificador(e.target.value)} />
                   <input type="hidden" value={calificador.items.tipo_formacion} onChange={(e) => setTipo_formacion(e.target.value)}  />
                   <input type="hidden" value={usuario.data.id_usuario} onChange={(e) => setId_cliente(e.target.value)}/>
                </div>
              )} */}
            <div className="redes-cont-id">

              <div className="redes-cont500">
                <input
                  type="hidden"
                  value={id}
                  name="id_auto"
                  id="id_auto"
                  onChange={(e) => setId_auto(e.target.value)}
                />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="1"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">1</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="2"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">2</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="3"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">3</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="4"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">4</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="5"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">5</label>
                </div>
              </div>
              <div className="redes-cont500">
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="6"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">6</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="7"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">7</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="8"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">8</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="9"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">9</label>
                </div>
                <br />
                <div>
                  <input
                    type="radio"
                    required
                    name="calificacion_votacion"
                    className="radio"
                    value="10"
                    onChange={(e) => setCalificacion_votacion(e.target.value)}
                  />
                  <label className="jugadorid-nume">10</label>
                </div>
              </div>
            </div>
            <div className="botones">
            <Button
      className="btn btn-primary btn-lg btn-block"
      disabled={isLoading}
      onClick={!isLoading ? submitHandler : null}
    >
      {isLoading ? 'Cargando…' : 'Enviar'}
    </Button>
              
              <button type="button" className="btn btn-primary-2 btn-lg btn-block" onClick={goBack}>Cancelar</button>
              {/* </NavLink> */}
            </div>
          </form>
          <br />
          {/* <div className="redes-cont3">
            {!auspiciantes3.items ? (
              <div className="imagen-home-promociones1-oculto"></div>
            ) : (
              <div>
                {auspiciantes3.items.map((auspiciante) => {
                  return (
                    <img
                      key={auspiciante.id_auspiciante}
                      src={`${config_server.linkImageAuspiciante}${auspiciante.imagen_auspiciante}`}
                      className="aus-jugadorid"
                      alt="auspiciantes"
                    />
                  );
                })}
              </div>
            )}
          </div> */}
          <br />
        </div>
      </div>
    );
  };
  const RenderAlert = () => {
    return (
      <div className="container-azul233">
        <div className="cab-verde">
          <h1 className="h1-1 centrar">Calificá</h1>
        </div>
        <br />
        <div className="container-azul">
          <br />
          <h1> No habilitado para calificar</h1>
          <br />
        </div>
      </div>
    );
  };
  const Render = () => {
    const estadoActual =calificador.filteredItems.calificador.estado_actual_calificador
   if(estadoActual == 1){
      return RenderCalificador();
   } else {
    return RenderAlert();
   }
  } 
  return (
    <React.Fragment>
      <section className="container-gr">
      {!calificador.filteredItems ? (
                <div></div>
              ) : (
                Render()
              )}
     
        </section>
      
    </React.Fragment>
  );
}
export default JugadorId;
