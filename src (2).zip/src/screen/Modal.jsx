import React from "react";
import ReactDOM from "react-dom";
import "../App.css";
import Iframe from "react-iframe";
import { ConsultaServer } from "../action/ConsultaServer";

const Modal = ({ isShowing, hide, url }) =>
  isShowing 
    ? ReactDOM.createPortal(
        <React.Fragment>
          <div className="modal-overlay" />

          <div
            className="modal-wrapper"
            aria-modal
            aria-hidden
            tabIndex={-1}
            role="dialog"
          >
            <div className="modal-header">
              <button
                type="button"
                className="close-modal"
                data-dismiss="modal"
                aria-label="Close"
                onClick={ async ()=>{
                  hide()
                  if(localStorage.id_compra_bono !== ""){
                    const userInfo = JSON.parse(localStorage.getItem("userInfo"));
                    const {data} = await ConsultaServer(
                      `/ventaBonos/procesarCompra/tigo/verificarTransaccion`,
                      "POST",
                      {
                        
                      },

                      {
                        id: localStorage.id_compra_bono,

                        
                      }
                    );
                    //console.log("tigo2",data)
                    localStorage.id_compra_bono =""
                  }

                }
                }
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <Iframe
              url={url}
              width="100%"
              height="100%"
              id="myId"
              className="myClassname"
              position="relative"
              allowFullScreen
            />
          </div>
        </React.Fragment>,
        document.body
      )
    : null;

export default Modal;
