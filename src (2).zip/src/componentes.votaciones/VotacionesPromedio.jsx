import React, { useEffect, useState } from "react";
import { useDispatch, useSelector} from "react-redux";
import { CardBody,Progress, Spinner } from "reactstrap";
import clienteAxios from "../config/axios";
import server from "../config/server";


function VotacionesPromedio(props) {
  const API = server.baseURL + "calautos/getCalificacionCliente/";
  const [calificaciones, setCalificaciones] = useState([]);
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const config_server = JSON.parse(localStorage.getItem("configServer"));

  const dispatch = useDispatch();

  let id_cliente = 0;
  if (userInfo == null) {
    window.location.replace("/");
  } else {
    id_cliente = userInfo.id_cliente === null ? 0 : userInfo.id_cliente;
  }
//   useEffect(() => {
//     fetch(API, {
//       method: "GET",
//     })
//       .then((response) => response.json())
//       .then((data) => {
//         setCalificaciones(data.data);
//       })

//       .catch((error) => {
//         console.log(error);
//       });
//   }, []);
  useEffect(() => {
    async function calificaciones(id_cliente) {
      const { data } = await clienteAxios.get(`calautos/getCalificacionCliente/${id_cliente}`, {
        headers: { Token: `Bearer ${userInfo.token}` },
      });
      setCalificaciones(data.data);
    }
     calificaciones(id_cliente);

  }, [dispatch, id_cliente, userInfo]);


  const renderCalificacion = (obj) => {
    return obj.map((cal) => {
      const calificacion = parseInt(cal.promedio);
      const porcentaje = parseInt(cal.porcentaje);
      const auto = cal.nombre_auto  ;
      const imagen = cal.imagen_auto !== "" ? cal.imagen_auto : "/fans/boy1-sm.png" ;
      const id = cal.id_auto
      let color = "";

      switch (true) {
        case porcentaje >= 0 && porcentaje <= 49:
          color = 'warning';
          break;
        case porcentaje >= 50 && porcentaje <= 79:
          color = 'primary';
          break;
        case porcentaje >= 80 && porcentaje <= 100:
          color = 'success';
          break;
      }

      return (
        <li className="mb-4 glass" key= {id} style={{listStyle:"none"}}>
          <div className="d-flex align-items-center" >
            <small style={{display:"flex",flexDirection:"row"}}>
              <img className="camiseta" src={`${config_server.linkImageAuto}${imagen}`} alt={auto}/>
              &nbsp;&nbsp;<h2 className="color-white">{auto}</h2>
            </small>
            <div className="ml-auto">
              <h2 className="h1-1">{calificacion}</h2>
            </div>
          </div>
          <Progress value={porcentaje} color={color}></Progress>
        </li>
      );
    });
  };

  return (
    <React.Fragment>
      
        
            
              
               
                <div className="centrar">
                  {calificaciones.length === 0 ? (
                   <h1> No tienes Calificaciones</h1>
                  ) : (
                    <div className="container-azul-inf" style={{marginLeft:"-5"}}>
                      {renderCalificacion(calificaciones)}
                    </div>
                  )} 
                  </div>
               
             
           
          
       
      
    </React.Fragment>
  );
}
export default VotacionesPromedio;
