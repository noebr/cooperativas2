import React, { useEffect, useState } from "react";
import { MetaTags } from "react-meta-tags";
import { useDispatch, useSelector } from "react-redux";
import clienteAxios from "../config/axios";
import { metaTags } from "../config/configuraciones";
import "react-web-tabs/dist/react-web-tabs.css";


export default function VotacionesCompletas(props) {
  const [vCompletas, setVCompletas] = useState("");
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const config_server = JSON.parse(localStorage.getItem("configServer"));


  let id_cliente = 0;
  if (userInfo == null) {
    window.location.replace("/");
  } else {
    id_cliente = userInfo.id_cliente === null ? 0 : userInfo.id_cliente;
  }

  const dispatch = useDispatch();

  useEffect(() => {
    async function vCompletas(id_cliente) {
      const { data } = await clienteAxios.get(`calautos/getCalificacion/${id_cliente}`, {
        headers: { Token: `Bearer ${userInfo.token}` },
      });
      setVCompletas(data.data);
    }
      vCompletas(id_cliente);

  }, [dispatch, id_cliente, userInfo]);

  
  return (
    <div className="votaciones-cu">

      <main style={{ margin: "1rem" }}>
        {vCompletas.length === 0 ? (
         <h1> No tienes Calificaciones</h1>
        ) : (
          <div>
            {vCompletas.map((votacion) => (

              <div className="lista-con-backg  container-azul317" key={votacion.id_votacion}>
                <div className="orden">
                  <h2>{votacion.nombre_auto} {votacion.apellido_auto}</h2>

                  <img
                    loading="lazy"
                    
                    src={`${config_server.linkImageAuto}/${votacion.imagen_auto}`}
                    className="sorteos-img"
                    alt="orden-compra"
                  />
                </div>
                <br />

                <div className="p">
                  <h2>Detalle:</h2>
                  <p className="p">Fecha de votación: {votacion.fecha_votacion}</p>

                  <p className="p">
                    <br />
                    Calificación:
                    <br />
                    {votacion.calificacion_votacion} Pts.
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}