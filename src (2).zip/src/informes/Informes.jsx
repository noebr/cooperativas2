import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CardBody, Progress, Spinner } from "reactstrap";
import clienteAxios from "../config/axios";
import imgvacia from "../assets/imagenes/fans/boy1-sm.png";
import { Animated } from "react-animated-css";

function Informes({ match }) {
  const { id } = match.params;
  const [calificaciones, setCalificaciones] = useState([]);
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const config_server = JSON.parse(localStorage.getItem("configServer"));
  console.log("id", id);

  const dispatch = useDispatch();

  let id_cliente = 0;
  const getInformes = async (id) => {
    const { data } = await clienteAxios.get(`/calautos/votaciones/getInformes/${id}`);
    setCalificaciones(data.data);
  };
  useEffect(() => {
    getInformes(id);
  }, []);

  const renderCalificacion = (obj) => {
    return obj.detalle1.map((cal) => {
      const calificacion = parseInt(cal.promedio);
      const porcentaje = parseInt(cal.porcentaje);
      const auto = cal.nombre_auto;
      const puntos = cal.votos;
      const participantes = cal.cantidad;
      const imagen =
        cal.imagen_auto !== "" ? cal.imagen_auto : imgvacia;
      const id = cal.id_auto;
      let color = "";

      switch (true) {
        case porcentaje >= 0 && porcentaje <= 49:
          color = "warning";
          break;
        case porcentaje >= 50 && porcentaje <= 79:
          color = "primary";
          break;
        case porcentaje >= 80 && porcentaje <= 100:
          color = "success";
          break;
      }

      return (
        <li className="mb-4 glass" key={id} style={{ listStyle: "none" }}>
          <Animated
            animationIn="flipInY"
            animationOut="flipOutY"
            animationInDuration={3000}
            animationOutDuration={3000}
            isVisible={true}
          >
            <div className="d-flex align-items-center">
              <small style={{ display: "flex", flexDirection: "row" }}>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <img
                    className="camiseta"
                    src={`${config_server.linkImageAuto}${imagen}`}
                    alt={auto}
                  />
                </div>
                <div>
                  <h2 className="color-white">{auto}</h2>
                  <h5 style={{ color: "white", marginLeft: "1rem" }}>
                    Puntos: {puntos} - Participantes: {participantes}
                  </h5>
                </div>
              </small>
              <div className="ml-auto">
                <h2 className="h1-1">{calificacion}</h2>
              </div>
            </div>

            <Progress
              width="500px"
              height="10px"
              value={porcentaje}
              animated
              color={color}
            ></Progress>
          </Animated>
        </li>
      );
    });
  };

  console.log("q1", calificaciones.detalle2);
  return (
    <React.Fragment>
      <div className="informes">
        {calificaciones.length === 0 ? (
          <h1> No tienes Calificaciones</h1>
        ) : (
          <div>
            <div className="container-azul-informes">
              {id == "hombres" && (
                <div>
                  {calificaciones.detalle2.map((ob2) => {
                    var porcentaje = 0;
                    if (ob2.total_votos > 0) {
                      porcentaje = parseInt((ob2.masculino / ob2.total_votos) * 100);
                    }
                    console.log("porcentaje", porcentaje);
                    return (
                      <div>
                        <h1 className="centrar">Informe por Hombres</h1>
                        <div className="cal-informes2">
                          <div>
                            <h2>Total de votantes : {ob2.total_votos}</h2>
                          </div>

                          <h2>Hombres : {ob2.masculino}</h2>

                          <h2 style={{ color: "#00afff" }}>
                            Porcentaje : {porcentaje} %
                          </h2>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {id == "mujeres" && (
                <div>
                  {calificaciones.detalle2.map((ob2) => {
                    var porcentaje = 0;
                    if (ob2.total_votos > 0) {
                      porcentaje = parseInt(
                        (ob2.femenino / ob2.total_votos) * 100
                      );
                    }

                    return (
                      <div>
                        <h1 className="centrar">Informe por Mujeres</h1>
                        <div className="cal-informes">
                          <h2>Total de votantes : {ob2.total_votos}</h2>

                          <h2>Mujeres : {ob2.femenino}</h2>

                          <h2 style={{ color: "rgb(144 243 233)" }}>
                            Porcentaje : {porcentaje} %
                          </h2>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {id == "socios" && (
                <div>
                  {calificaciones.detalle2.map((ob2) => {
                    var porcentaje = 0;
                    if (ob2.total_votos > 0) {
                      porcentaje = parseInt(
                        (ob2.socio / ob2.total_votos) * 100
                      );
                    }

                    return (
                      <div>
                        <h1 className="centrar">Informe por Socios</h1>
                        <div className="cal-informes3">
                          <h2>Total de votantes : {ob2.total_votos}</h2>

                          <h2>Socios : {ob2.socio}</h2>

                          <h2 style={{ color: "rgb(37 40 114)" }}>
                            Porcentaje : {porcentaje} %
                          </h2>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {id == "nosocios" && (
                <div>
                  {calificaciones.detalle2.map((ob2) => {
                    var porcentaje = 0;
                    if (ob2.total_votos > 0) {
                      porcentaje = parseInt(
                        (ob2.nosocio / ob2.total_votos) * 100
                      );
                    }
                    return (
                      <div>
                        <h1 className="centrar">Informe por No Socios</h1>
                        <div className="cal-informes4">
                          <h2>Total de votantes : {ob2.total_votos}</h2>

                          <h2>No socios : {ob2.nosocio}</h2>

                          <h2 style={{ color: "rgb(37 40 114)" }}>
                            Porcentaje : {porcentaje} %
                          </h2>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {id == "general" && (
                <div>
                    {calificaciones.detalle2.map((ob2) => {
                    var socios = 0;
                    var nosocios = 0;
                    var femenino = 0;
                    var masculino = 0;

                    console.log("Total",ob2.total_votos);
                    if (ob2.total_votos > 0) {
                      nosocios = parseInt((ob2.nosocio / ob2.total_votos) * 100);
                      socios = parseInt((ob2.socio / ob2.total_votos) * 100);
                      femenino = parseInt((ob2.femenino / ob2.total_votos) * 100);
                      masculino = parseInt((ob2.masculino / ob2.total_votos) * 100);
                    }
                    return (
                      <div>
                        <h1 className="centrar">Informe General</h1>
                        <div className="cal-informes5">
                          <h2 className="centrar">Total de votantes : {ob2.total_votos}</h2>
                          {/* <div className="totales-informes">
                            <h2 style={{ color: "rgb(149 255 135)" }}>
                              Socios : {socios} %
                            </h2>
                            <h2 style={{ color: "rgb(242 249 123)" }}>
                              No Socios : {nosocios} %
                            </h2>
                          </div> */}
                          
                          <div className="totales-informes">
                            <h2 style={{ color: "#ff7c93" }}>
                              Mujeres : {femenino} %
                            </h2>
                            <h2 style={{ color: "rgb(118 219 249)" }}>
                              Hombres : {masculino} %
                            </h2>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            <div className="container-azul-informes">
              {renderCalificacion(calificaciones)}
            </div>
          </div>
        )}
      </div>
    </React.Fragment>
  );
}
export default Informes;
