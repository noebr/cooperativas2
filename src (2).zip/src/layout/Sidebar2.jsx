import React from "react";
import '../App.css';
import { Link } from "react-router-dom";
import BotonUser from "../userBotones/BotonUser";




class Sidebar2 extends React.Component {

  
    render () {
      const closeMenu = () => {
        document.querySelector(".sidebar").classList.remove("open");
      };

      return (
        
        <div className="lista">
                  
          <Link style={{background:"none"}} className="lista-sidebar" onClick={closeMenu} to="/signin" id="Juegos" > <BotonUser /></Link> 
          <hr className="hr2"/> 
          <Link  onClick={closeMenu} to="/como-participar" className="lista-sidebar">¿Cómo participar?</Link>
          <hr className="hr2"/> 
          <a href="/#califica" onClick={closeMenu}  className="lista-sidebar">Calificá</a>
          <hr className="hr2"/> 
          <a href="/#graficos"onClick={closeMenu}  className="lista-sidebar">Calificaciones</a>
          <hr className="hr2"/> 
          <a href="/#contacto"  onClick={closeMenu}   className="lista-sidebar">Contacto</a>

          

        
        </div>
      );
    }
  }
  export default Sidebar2;