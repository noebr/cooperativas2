import React, { Component } from "react";
import { connect } from "react-redux";
import { filterProducts2, sortProducts } from "../action/ProductActions";
import Spinner from "../componentes/Spinner";

class Buscador extends Component {
  render() {
    return !this.props.filteredProducts ? (
      <div><Spinner/></div>
    ) : (
      <div>
        <li>
          <form>
            
            <input
              className="search"
              type="search"
              id="search"
              placeholder="  Buscar"
              value={this.props.products.nombre_producto}
              onChange={(e) =>
                this.props.filterProducts2(this.props.products, e.target.value)
              }
            /> 
           
          </form>
        </li>
      </div>
    );
  }
}
export default connect(
  (state) => ({
    nombre_producto: state.products.nombre_producto,
    sort: state.products.sort,
    products: state.products.items,
    filteredProducts: state.products.filteredItems,
  }),
  {
    filterProducts2,
    sortProducts,
  }
)(Buscador);
