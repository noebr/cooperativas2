  
import React, { Component } from "react";
import { connect } from "react-redux";
import { filterProducts, sortProducts } from "../action/ProductActions";
import Spinner from "../componentes/Spinner";
import Buscador from '../filters/Buscador'


class Filter extends Component {
  render() {
    
// console.log("filter",this.props)
    return !this.props.filteredProducts ? (
      <div className="centrar"><Spinner/></div>
    ) : (
      
      <div className="filter">
     
          <select
              value={this.props.products.category}
              onChange={(e) =>
                this.props.filterProducts(this.props.products, e.target.value)
              }
              className="filter-1"
            >
               <option value="">Categorías</option>
              
              {this.props.products.categorias.map((product) => (
            
            <option key={product.id_categoria} value={product.id_categoria}>{product.nombre_categoria}</option>
            
            ))}
          <option value="">Ver todo</option>
          </select>
          
        <div className="filter-buscador">
          <Buscador />
        </div>
      </div>
    );
  }
}
export default  connect(
  (state) => ({
   
    category: state,
    sort: state.products.sort,
    products: state.products.items,
    filteredProducts: state.products.filteredItems,
  }),
  {
    filterProducts,
    sortProducts,
  }
)(Filter);