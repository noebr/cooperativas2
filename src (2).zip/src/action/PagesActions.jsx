import { ConsultaServer } from "./ConsultaServer";



// export const fetchProducts = () => async (dispatch) => {
    
//     const data = await ConsultaServer(`/product/st/listar`, "GET" );

//     return data;
//   };


  export const detailsNotas = async (productId) => {
    
    const data = await ConsultaServer(`/paginas/noticias/${productId}`, "GET" );

    return data;
  };
