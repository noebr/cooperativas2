import {
  REGISTER_REPRESENTANTE_REQUEST,
  REGISTER_REPRESENTANTE_SUCCESS,
  REGISTER_REPRESENTANTE_FAIL,
} from "../constants/ProjectType";
import clienteAxios from "../config/axios";
import swal from "sweetalert";

const enviarVotaciones =
  (id_calificador, tipo_formacion, id_cliente, calificacion_votacion,id_auto ) =>
  async (dispatch) => {
    dispatch({
      type: REGISTER_REPRESENTANTE_REQUEST,
      payload: {
        id_calificador: id_calificador,
        tipo_formacion: tipo_formacion,
        id_cliente: id_cliente,
        calificacion_votacion: calificacion_votacion,
        id_auto:id_auto
        
      },
    });

    try {
      const { data } = await clienteAxios.post("calautos/votaciones/add", {
        id_calificador,
        tipo_formacion,
        id_cliente,
        calificacion_votacion,
        id_auto
        
      });
      dispatch({ type: REGISTER_REPRESENTANTE_SUCCESS, payload: data.data });
      if (data.status === "success") {
        swal({
          title: "¡Gracias!",
          text: "La calificación fue enviada con éxito",
          icon: "success",
          closeOnClickOutside: false,
          closeOnEsc: false,
          allowOutsideClick: false,
          SuccessMode: true,
        }).then((willDelete) => {
          window.location.replace("/");
        });
          
      } else {
        swal({
          title: "¡Ups!",
          text: data.message,
          icon: "",
          dangerMode: true,
        }).then((willDelete) => {
          if (willDelete) {
          }
        });
      }
    } catch (error) {
      swal({
        title: "¡Ups!",
        text: error.message,
        icon: "",
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
        }
      });
      dispatch({ type: REGISTER_REPRESENTANTE_FAIL, payload: error.message });
    }
  };
  

export { enviarVotaciones };
