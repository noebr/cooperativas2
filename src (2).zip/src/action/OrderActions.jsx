import swal from 'sweetalert';
import {
  ORDER_CREATE_SUCCESS, ORDER_CREATE_FAIL,
  ORDER_DETAILS_REQUEST, ORDER_DETAILS_SUCCESS, ORDER_DETAILS_FAIL,
  CART_EMPY
} from "../constants/OrderType";
import clienteAxios from "../config/axios";
import { ConsultaServer } from './ConsultaServer';

export const createOrder = (id_usuario,nombre,ruc_cliente,email,monto_compra,cartItems) => async (dispatch, getState) => {
  const monto = cartItems.cartItems.reduce((a, c) => a + c.precio_compra * c.count, 0)
  
  
  try {
    const {
      userSignin: { userInfo },
    } = getState();
    if (userInfo.total_puntos < monto) {
      
      swal({
        title: "¡Ups !",
        text: "No tienes los puntos suficientes para canjear",
        icon: "error",
        dangerMode: true,
      })
      .then(willDelete => {
        if (willDelete) {
         window.location.replace('/');
         
        }
      });
    } 
    
  const { data } = await clienteAxios.post("/product/comprarProducto", { id_usuario:id_usuario,nombre:nombre,ruc_cliente:ruc_cliente,email:email,monto_compra:monto,cartItems:cartItems.cartItems },
   { headers: { Token: `Bearer ${userInfo.token}` }
  });
  //console.log("data",data.status);
  if (data.status === "success") {
    swal({
      title: "Gracias !",
      text: "Tus puntos han sido canjeados",
      icon: "success",
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        // dispatch(detailsOrder(id_cliente));
        window.location.replace("/");
      }
    });
    dispatch({ type: ORDER_CREATE_SUCCESS, payload: data.order });
    dispatch({ type: CART_EMPY });
    localStorage.removeItem('cartItems');
    
  } else{
    swal({
      title: "¡Ups!",
      text: data.message,
      icon: "",
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
      }
    });
  }
  } catch (error) {

    dispatch({
      type: ORDER_CREATE_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};

export const detailsOrder = (id_cliente) => async (dispatch, getState) => {
  dispatch({ type: ORDER_DETAILS_REQUEST, payload: id_cliente });
  const {
    userSignin: { userInfo },
  } = getState();
  try {
    //console.log("entro")
    const { data } = await clienteAxios.get(`calautos/edit/${id_cliente}`,{
      headers: { Token: `Bearer ${userInfo.token}` },
    });
    if (data.status === "success") {

      dispatch({ type: ORDER_DETAILS_SUCCESS, payload: data.data.pedidos });
      localStorage.setItem('facturacion', JSON.stringify(data.data.pedidos));
      
    } else{
      swal({
        title: "¡Ups!",
        text: data.message,
        icon: "",
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          window.location.replace("/");
        }
      });
    }

    //console.log("hola",data.data)
  } catch (error) {
    swal({
      title: "¡Ups!",
      text: error.message,
      icon: "",
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
      }
    });
    const message =
      error.response && error.response.data.message
        ? error.response.data.message
        : error.message;
    dispatch({ type: ORDER_DETAILS_FAIL, payload: message });
  }
};

export const detailsOrder2 = (id_cliente) => async (dispatch, getState) => {
  dispatch({ type: ORDER_DETAILS_REQUEST, payload: id_cliente });
  const {
    userSignin: { userInfo },
  } = getState();
  try {
    //console.log("entro")
    const { data } = await clienteAxios.get(`product/misTickets/${id_cliente}`,{
      headers: { Token: `Bearer ${userInfo.token}` },
    });
    if (data.status === "success") {

      dispatch({ type: ORDER_DETAILS_SUCCESS, payload: data.data.pedidos });
      localStorage.setItem('facturacion', JSON.stringify(data.data.pedidos));
      
    } else{
      swal({
        title: "¡Ups!",
        text: data.message,
        icon: "",
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          window.location.replace("/");
        }
      });
    }

  } catch (error) {
    swal({
      title: "¡Ups!",
      text: error.message,
      icon: "",
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
      }
    });
    const message =
      error.response && error.response.data.message
        ? error.response.data.message
        : error.message;
    dispatch({ type: ORDER_DETAILS_FAIL, payload: message });
  }
};


export const createOrderBonos = (
  token,
  idCliente,
  valorMonto,
  metodoPago,
  idVentaBono,
  idJuego,
  toggle
) => async (dispatch) => {
  try {
    const {data} = await ConsultaServer(
      `/ventaBonos/procesarCompra`,
      "POST",
      { Token: `Bearer ${token}` },
      {
        idCliente: idCliente,
        valorMonto: valorMonto,
        metodoPago: metodoPago,
        idVentaBono: idVentaBono,
        idJuego: idJuego,
        
      }
    );
    if(data.company === "tigo"){
      toggle(data.url.redirectUrl);
      localStorage.id_compra_bono=data.reference;
    }else if (data.company === "personal") {
      toggle(data.url);
    }
    dispatch({ type: ORDER_CREATE_SUCCESS, payload: data.order });
  } catch (error) {
    swal({
      title: "¡Ups!",
      text: error.message,
      icon: "",
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
      }
    });

    dispatch({
      type: ORDER_CREATE_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};







