import {
  FETCH_PRODUCTS2
} from "../constants/ProductType";
import swal from 'sweetalert';
import clienteAxios from '../config/axios';


export const fetchAuspiciantes2 = () => async (dispatch) => {
    // dispatch({
    //   type: PRODUCT_LIST_REQUEST,
    // });
  
    try {
      const { data } = await clienteAxios.get('calautos/verAuspiciantes2');
      dispatch({ type: FETCH_PRODUCTS2, payload: data.data });  
    } catch (error) {
    //   dispatch({ type: PRODUCT_LIST_FAIL, payload: error.message }); 
        swal({
          title: "¡Ups !",
          text: error.message,
          icon: "error",
          dangerMode: true,
        })
        .then(willDelete => {
          if (willDelete) {
           window.location.replace('/');
           
          }
        });
    }
  };