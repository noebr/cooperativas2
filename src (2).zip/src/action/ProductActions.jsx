
  import { URL_SERVER } from "../constants/UserType";
  import {
    PRODUCT_LIST_REQUEST,
    PRODUCT_LIST_FAIL,
    PRODUCT_REVIEW_SAVE_REQUEST,
    PRODUCT_REVIEW_SAVE_FAIL,
    PRODUCT_REVIEW_SAVE_SUCCESS,
    PRODUCT_DETAILS_REQUEST,
    PRODUCT_DETAILS_SUCCESS,
    PRODUCT_DETAILS_FAIL,
    FILTER_PRODUCTS_BY_CATEGORY,
    ORDER_PRODUCTS_BY_PRICE,
    FETCH_PRODUCTS
  } from "../constants/ProductType";
  import axios from "axios";
  import swal from 'sweetalert';
  import clienteAxios from '../config/axios';
import { ConsultaServer } from "./ConsultaServer";
  
  export const fetchProducts = () => async (dispatch) => {
    dispatch({
      type: PRODUCT_LIST_REQUEST,
    });
  
    try {
      const { data } = await clienteAxios.get('/product/st/listar');
      dispatch({ type: FETCH_PRODUCTS, payload: data.data });  
    } catch (error) {
      dispatch({ type: PRODUCT_LIST_FAIL, payload: error.message }); 
        swal({
          title: "¡Ups !",
          text: error.message,
          icon: "error",
          dangerMode: true,
        })
        .then(willDelete => {
          if (willDelete) {
           window.location.replace('/');
           
          }
        });
    }
  };
  
  export const filterProducts = (products, id_categoria) => (dispatch) => {
    // console.log("hola",products)
    const filProduct = products.productos.filter(
      (x) => x.id_categoria.indexOf(id_categoria) >= 0
    );
    const category = products.categorias.filter(
      (x) => x.id_categoria.indexOf(id_categoria) >= 0
    );
    const productos = {
      productos: filProduct,
      categorias: category,
      
    };
    // console.log(productos, products);
    dispatch({
      type: FILTER_PRODUCTS_BY_CATEGORY,
      payload: {
        id_categoria: id_categoria,
        items: productos,
      },
    });
  };
  
  export const filterProducts2 = (products, nombre_producto) => (dispatch) => {
    const filProduct = products.productos.filter(
      (x) => (x.nombre_producto).toLowerCase().indexOf(nombre_producto.toLowerCase()) >= 0
    );
    const category = products.categorias

    const productosCategorias = {
      productos: filProduct,
      categorias: category,
     
    };
    //console.log("productos2",productosCategorias );
    dispatch({
      type: FILTER_PRODUCTS_BY_CATEGORY,
      payload: {
        nombre_producto: nombre_producto,
        items: productosCategorias,
      },
    });
  };
  
  
  
  
  
  export const sortProducts = (filteredProducts, sort) => (dispatch) => {
    const sortedProducts = filteredProducts.slice();
    if (sort === "latest") {
      sortedProducts.sort((a, b) => (a._id > b._id ? 1 : -1));
    } else {
      sortedProducts.sort((a, b) =>
        sort === "lowest"
          ? a.price > b.price
            ? 1
            : -1
          : a.price > b.price
          ? -1
          : 1
      );
    }
    //console.log(sortedProducts);
    dispatch({
      type: ORDER_PRODUCTS_BY_PRICE,
      payload: {
        sort: sort,
        items: sortedProducts,
      },
    });
  };
  

  
  export const detailsProduct = (productId) => async (dispatch) => {
    
    try {
      dispatch({ type: PRODUCT_DETAILS_REQUEST, payload: productId });
      const data = await clienteAxios.get(`/product/${productId}`);
      //console.log("details", data);
      dispatch({ type: PRODUCT_DETAILS_SUCCESS, payload: data.data });
    } catch (error) {
      dispatch({ type: PRODUCT_DETAILS_FAIL, payload: error.message });
      swal({
        title: "¡Ups !",
        text: error.message,
        icon: "error",
        dangerMode: true,
      })
      .then(willDelete => {
        if (willDelete) {
         window.location.replace('/');
         
        }
      });
    }
   
  };
  
  export const saveProductReview = (
    comment,
    rating,
    id_producto,
    id_usuario
  ) => async (dispatch) => {
   // console.log(comment, rating, id_producto, id_usuario);
  
    try {
      dispatch({
        type: PRODUCT_REVIEW_SAVE_REQUEST,
        payload: {
          comment: comment,
          rating: rating,
          id_producto: id_producto,
          id_usuario: id_usuario,
        },
      });
      // const get = `?comment=${comment}&rating=${rating}&id_producto=${id_producto}&id_usuario=${id_usuario}`
      const { data } = await axios.post(URL_SERVER + `/products/reviews`, {
        comment: comment,
        rating: rating,
        id_producto: id_producto,
        id_usuario: id_usuario,
      });
  
      dispatch({ type: PRODUCT_REVIEW_SAVE_SUCCESS, payload: data.data });
    } catch (error) {
      dispatch({ type: PRODUCT_REVIEW_SAVE_FAIL, payload: error.message });
    }
  };
  
  export const detailsProduct2 = async (productId) => {
    //console.log("##debug")
    try {
      const data = await clienteAxios.get(`/product/st/detalle/${productId}`);
      
      // console.log("details",data);
      return data;
    } catch (error) {
       swal({
        title: "¡Ups !",
        text: error.message,
        icon: "error",
        dangerMode: true,
      })
      .then(willDelete => {
        if (willDelete) {
         window.location.replace('/');
         
        }
      });
    }
   
  };
  


  export const detailsBonos = async (bonosId,token="") => {
    
    const data = await ConsultaServer(`/ventaBonos/detalle/${bonosId}`, "GET", {
      Token: `Bearer ${token}`,
      
    });

    return data;
  };
  
  