// import {CONFIG_REQUEST,CONFIG_SUCCESS,CONFIG_FAIL } from "../constants/ConfigType";
// import clienteAxios from '../config/axios';


// function excepciones (ns){
//     this.message = ns
//   }
//   const configServer = () => async (dispatch) => {
//     console.log("paso1")
//     dispatch({ type: CONFIG_REQUEST, payload: { } });
  
//     try {
//         console.log("paso2")
//       const { data } = await clienteAxios.post("/paginas/configuraciones", {  });
//       if(data.status !== "success"){
//         console.log("paso3")
//         throw new excepciones(data.message)
        
//       }
      
//        dispatch({ type: CONFIG_SUCCESS, payload: data.data });
  
//       localStorage.setItem('configServer', JSON.stringify(data.data));
//       console.log()
//     } catch (error) {
//       console.log(error.message)
//       dispatch({ type: CONFIG_FAIL, payload: error.message });
//     }
  
//   }
//   export {configServer};