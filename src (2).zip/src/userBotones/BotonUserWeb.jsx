import React from "react";
import { Link } from "react-router-dom";

import { useSelector } from "react-redux";
import "../App.css";

function BotonUserWeb(props) {
  // const dispatch = useDispatch();

  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;

  return (
    <React.Fragment>
      {userInfo ? (
  <React.Fragment/>
      ) : (
        // <Link to="/">
        //   <button type="button" onClick={handleLogout} className="sesion">

        //     <p>Salir</p><br/>
        //   </button>
        // </Link>

        <Link to="/signin" className="lista-sidebar-signin-web">

            Iniciar sesión
          
        </Link>
      )}
    </React.Fragment>
  );
}

export default BotonUserWeb;
