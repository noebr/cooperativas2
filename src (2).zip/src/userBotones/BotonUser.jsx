import React from "react";
import { Link } from "react-router-dom";

import { useSelector } from "react-redux";
import "../App.css";

function BotonUser(props) {
  // const dispatch = useDispatch();

  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;

  return (
    <React.Fragment>
      {userInfo ? (
  <React.Fragment/>
      ) : (
        // <Link to="/">
        //   <button type="button" onClick={handleLogout} className="sesion">

        //     <p>Salir</p><br/>
        //   </button>
        // </Link>

        <Link to="/signin" style={{color:"rgba(255,255,255,.5)",marginTop:"1rem"}}>

            Iniciar sesión
          
        </Link>
      )}
    </React.Fragment>
  );
}

export default BotonUser;
