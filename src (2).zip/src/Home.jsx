import React from "react";
import Formacion1 from "../alineaciones/Formacion1";
import Formacion2 from "../alineaciones/Formacion2";
import Formacion3 from "../alineaciones/Formacion3";
import Formacion4 from "../alineaciones/Formacion4";
import Formacion5 from "../alineaciones/Formacion5";
import Formacion6 from "../alineaciones/Formacion6";
import Formacion7 from "../alineaciones/Formacion7";
import Formacion8 from "../alineaciones/Formacion8";
import Formacion9 from "../alineaciones/Formacion9";
import "../App.css";
import DatosPartido from "../componentes.home/DatosPartido";
import GraficosVotaciones from "../componentes.home/GraficosVotaciones";


function Home() {
  return (
    <div className="app">
      {/* <VideoCentral /> */}
      <h1 className="h1 centrar">
      Calificá a los mejores
      </h1>
      <br />
      <br />
      <DatosPartido/>
      <br />
      <br />
       {/* <Formacion1/>   */}
       {/* <Formacion2/>  */}
       <Formacion3/> 
      {/* <Formacion4/> */}
      {/* <Formacion5/> */}
      {/* <Formacion6/> */}
      {/* <Formacion7/> */}
      {/* <Formacion8/> */}
      {/* <Formacion9/> */}

      <div className="graficos">
      <GraficosVotaciones/>
      </div>

      
    </div>
  );
}

export default Home;
