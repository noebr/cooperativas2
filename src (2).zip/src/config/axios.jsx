import axios from 'axios';
import server from "./server"

const clienteAxios = axios.create({
    baseURL: server.baseURL
});

export default clienteAxios;