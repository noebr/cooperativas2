import React, { Component } from "react";
import "../App.css";
import "react-web-tabs/dist/react-web-tabs.css";
import { Tabs, Tab, TabPanel, TabList } from "react-web-tabs";
import VotacionesCompletas from "../componentes.votaciones/VotacionesCompletas";
import VotacionesPromedio from "../componentes.votaciones/VotacionesPromedio";
import Porjugador from "../componentes/modals/Porjugador";
import Resumen from "../componentes/modals/Resumen"

class PedidosHome extends Component {
  render() {
    return (
      <React.Fragment>
        <Tabs
          defaultTab="one"
          onChange={(tabId) => {
            console.log(tabId);
          }}
        >
          <div className="votaciones">
            <div className="cab-verde">
              <h1 className="h1-1 centrar">Mis Calificaciones</h1>{" "}
            </div>
          </div>
          <br/>

          <TabList className="tabs-container">
            <Tab tabFor="one" className="tab">
              <h2>Todas</h2>
              <Resumen/>
            </Tab>
            <Tab tabFor="two" className="tab">
              <h2>Por auto</h2>
              <Porjugador/>
            </Tab>
            {/* <Tab tabFor="three">
              <h2>Por encuentro</h2>
            </Tab> */}
          </TabList>
          <main>
            <TabPanel tabId="one"><VotacionesCompletas/></TabPanel>
            <TabPanel tabId="two"><VotacionesPromedio/></TabPanel>
            {/* <TabPanel tabId="three"></TabPanel> */}
          </main>
        </Tabs>
      </React.Fragment>
    );
  }
}
export default PedidosHome;
