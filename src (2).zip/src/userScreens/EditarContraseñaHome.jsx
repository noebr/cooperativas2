import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { updateUserContrasena } from "../action/UserActions";
import SolidButton from "../componentes/buttons/SolidButton";
import swal from "sweetalert";

import { USER_UPDATE_PROFILE_RESET } from "../constants/UserType";
import { MetaTags } from "react-meta-tags";
import { metaTags } from "../config/configuraciones";

export default function EditarContraseñaHome() {
  const [old_password, setOld_password] = useState("");
  const [new_password, setNew_password] = useState("");
  const [repeat_password, setRepeat_password] = useState("");

  // const cart = useSelector((state) => state.cart);

  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const userDetails = useSelector((state) => state.userDetails);
  const { user } = userDetails;
  // const userUpdateProfile = useSelector((state) => state.userUpdateProfile);
  // const {
  //   success: successUpdate,
  //   error: errorUpdate,
  //   loading: loadingUpdate,
  // } = userUpdateProfile;
  const dispatch = useDispatch();
  useEffect(() => {
    if (!user) {
      dispatch({ type: USER_UPDATE_PROFILE_RESET });
      // dispatch(detailsUser(userInfo.id_usuario));
    } else {
      setOld_password(userInfo.old_password);
      setNew_password(userInfo.new_password);
      setRepeat_password(userInfo.repeat_password);
    }
  }, [dispatch, userInfo, user]);
  const submitHandler = (e) => {
    e.preventDefault();
    // dispatch update profile
    if (new_password !== repeat_password) {
      swal({
        title: "Sus Contraseñas no coinciden",
        
        dangerMode: true,
        button: "ok",
        closeModal: true,
      }).then((willDelete) => {
        if (willDelete) {
          
        }
      });
      
    } else {
      dispatch(
        updateUserContrasena({
          userId: userInfo.id_usu,
          old_password,
          new_password,
          repeat_password,
        })
      );

    }
  };
  return (
    <div>
            <MetaTags>
        <title>{metaTags.editcHome.title}</title>
        
        <meta charSet={metaTags.generales.charSet} />
        <link rel="icon" href={metaTags.generales.imgLogo} />
        <meta name="viewport" content={metaTags.generales.imgviewport} />
        <meta name="theme-color" content={metaTags.generales.color} />
        <link rel="apple-touch-icon" href={metaTags.generales.imgLogo} />
        <link rel="manifest" href={metaTags.generales.manifest} />
      </MetaTags>
      
        <main className="cuerpo-cu">
          <h1 className="h1 centrar">Cambiar Contraseña</h1>
          <div className="container-contraseña container-cuenta13">
          
            <form onSubmit={submitHandler}>
              <label className="label">Contraseña anterior</label>
              <input
                className="input-cuenta"
                id="old_password"
                type="password"
                onChange={(e) => setOld_password(e.target.value)}
              ></input>
<hr className="hr" />
              <label className="label">Nueva contraseña</label>
              <input
                className="input-cuenta"
                id="new_password"
                type="password"
                onChange={(e) => setNew_password(e.target.value)}
              ></input>
<hr className="hr" />
              <label className="label">Repetir contraseña</label>
              <input
                className="input-cuenta"
                id="repeat_password"
                type="password"
                onChange={(e) => setRepeat_password(e.target.value)}
              ></input>

              <div className="centrar-botones">
                <SolidButton txt="Guardar"></SolidButton>
              </div>
            </form>
          </div>
        </main>
      </div>
    
  );
}
