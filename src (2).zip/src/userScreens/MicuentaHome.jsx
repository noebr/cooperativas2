import React, { useEffect, useState } from "react";
import { MetaTags } from "react-meta-tags";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { updateUserProfile } from "../action/UserActions";
import SolidButton from "../componentes/buttons/SolidButton";
import { metaTags } from "../config/configuraciones";

import { USER_UPDATE_PROFILE_RESET } from "../constants/UserType";

export default function MicuentaHome() {
  const [nombre, setNombre] = useState("");
  const [apellido, setApellido] = useState("");
  const [tipo_documento, setTipo_documento] = useState("");
  const [ruc_cliente, setRuc_cliente] = useState("");
  const [fecha_nac, setFecha_nac] = useState("");
  const [nickname, setNickname] = useState("");
  const [email, setEmail] = useState("");
  const [telefono, setTelefono] = useState("");
  const [direccion, setDireccion] = useState("");
  const [actividad_economica, setActividad_economica] = useState("");
  const contrasena = "";
  const nueva_contrasena = "";

  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const userDetails = useSelector((state) => state.userDetails);
  const { user } = userDetails;

  const dispatch = useDispatch();
  useEffect(() => {
    if (!user) {
      dispatch({ type: USER_UPDATE_PROFILE_RESET });
      // dispatch(detailsUser(userInfo.id_cliente));
    } else {
      setNombre(userInfo.nombre);
      setApellido(userInfo.apellido);
      setTipo_documento(user.tipo_documento);
      setRuc_cliente(userInfo.ruc_cliente);
      setFecha_nac(userInfo.fecha_nac);
      setNickname(userInfo.nickname);
      setEmail(userInfo.email);
      setTelefono(userInfo.telefono);
      setDireccion(userInfo.direccion);
      setActividad_economica(userInfo.actividad_economica);
    }
  }, [dispatch, userInfo, user]);
  const submitHandler = (e) => {
    e.preventDefault();
    // dispatch update profile
    if (contrasena !== nueva_contrasena) {
      alert("Sus Contraseñas no coinciden");
    } else {
      dispatch(
        updateUserProfile({
          userId: userInfo.id_usu,
          nombre,
          apellido,
          tipo_documento,
          ruc_cliente,
          fecha_nac,
          nickname,
          email,
          telefono,
          direccion,
          actividad_economica,
        })
      );
      alert("Se realizaron los cambios con exito!");
    }
  };
  //console.log("userDetails", userDetails);
  return (
    <div>
      <MetaTags>
        <title>{metaTags.cuentaHome.title}</title>
        
        <meta charSet={metaTags.generales.charSet} />
        <link rel="icon" href={metaTags.generales.imgLogo} />
        <meta name="viewport" content={metaTags.generales.imgviewport} />
        <meta name="theme-color" content={metaTags.generales.color} />
        <link rel="apple-touch-icon" href={metaTags.generales.imgLogo} />
        <link rel="manifest" href={metaTags.generales.manifest} />
      </MetaTags>
      <div className="container-micuenta">
        <main>
          <h1 className="h1 centrar">Mi cuenta</h1>
          <div className="container-cuenta13">
            <form onSubmit={submitHandler}>
              <div className="container-login-perfil2-md">
                <label className="label1">Nombre</label>
                <input
                  className="input-cuenta"
                  id="nombre"
                  type="text"
                  value={userInfo.nombre}
                  onChange={(e) => setNombre(e.target.value)}
                ></input>
                <hr className="hr" />
                <label className="label1">Apellido</label>
                <input
                  className="input-cuenta"
                  id="apellido"
                  type="text"
                  value={userInfo.apellido}
                  onChange={(e) => setApellido(e.target.value)}
                ></input>
                <hr className="hr" />
                <label className="label1">Tipo de documento</label>
                <input
                  className="input-cuenta"
                  id="tipo_documento"
                  type="text"
                  value={userInfo.tipo_documento}
                  onChange={(e) => setTipo_documento(e.target.value)}
                ></input>
                <hr className="hr" />

                <label className="label1">Documento</label>
                <input
                  className="input-cuenta"
                  id="documento"
                  type="documento"
                  value={userInfo.ruc_cliente}
                  onChange={(e) => setRuc_cliente(e.target.value)}
                ></input>
                <hr className="hr" />
                <label className="label1">Fecha de nacimiento</label>
                <input
                  className="input-cuenta"
                  id="fecha_nac"
                  type="text"
                  value={userInfo.fecha_nac}
                  onChange={(e) => setFecha_nac(e.target.value)}
                ></input>

                
                <hr className="hr" />
                <label className="label1">Correo eléctronico</label>
                <input
                  className="input-cuenta"
                  id="email"
                  type="email"
                  value={userInfo.email}
                  onChange={(e) => setEmail(e.target.value)}
                ></input>

                <hr className="hr" />

                <label className="label1">Teléfono</label>
                <input 
                  className="input-cuenta"
                  id="telefono"
                  type="documento"
                  value={userInfo.telefono}
                  onChange={(e) => setTelefono(e.target.value)}
                  readOnly
                ></input>
              </div>
            </form>
          </div>
          <div className="centrar-botones">
            <Link to="/editar-cuenta">
              <SolidButton type="secondary" txt="Editar"></SolidButton>
            </Link>
            <Link to="/editar-contraseña">
              <SolidButton
                type="tertiary"
                txt="Cambiar contraseña"
              ></SolidButton>
            </Link>
          </div>
        </main>
        
      </div>
    </div>
  );
}
