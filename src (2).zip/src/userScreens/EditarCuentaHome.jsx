import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {  updateUserProfile } from "../action/UserActions";
import SolidButton from "../componentes/buttons/SolidButton";
import "../index.css"

import { USER_UPDATE_PROFILE_RESET } from "../constants/UserType";

export default function EditarCuentaHome() {
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;

  const [nombre, setNombre] = useState(userInfo.nombre);
  const [apellido, setApellido] = useState(userInfo.apellido);
  const [tipo_documento, setTipo_documento] = useState(userInfo.id_tipo_documento);
  const [ruc_cliente, setRuc_cliente] = useState(userInfo.ruc_cliente);
  const [fecha_nac, setFecha_nac] = useState(userInfo.fecha_nac);
  const [email, setEmail] = useState(userInfo.email);
  const [telefono, setTelefono] = useState(userInfo.telefono);

  const contrasena = userInfo.contrasena;
  const nueva_contrasena =userInfo.nueva_contrasena;

  // const cart = useSelector((state) => state.cart);
  

  const userDetails = useSelector((state) => state.userDetails);
  const { user } = userDetails;
  // const userUpdateProfile = useSelector((state) => state.userUpdateProfile);
  // const {
  //   success: successUpdate,
  //   error: errorUpdate,
  //   loading: loadingUpdate,
  // } = userUpdateProfile;
  const dispatch = useDispatch();
  useEffect(() => {
    if (!user) {
      dispatch({ type: USER_UPDATE_PROFILE_RESET });
     
    } else {
      setNombre(userInfo.nombre);
      setApellido(userInfo.apellido);
      setTipo_documento(userInfo.id_tipo_documento);
      setRuc_cliente(userInfo.ruc_cliente);
      setFecha_nac(userInfo.fecha_nac);
      setEmail(userInfo.email);
      setTelefono(userInfo.telefono);

 
    }
  }, [dispatch, userInfo, user]);
  const submitHandler = (e) => {
    e.preventDefault();
    // dispatch update profile
    if (contrasena !== nueva_contrasena) {
      alert("Sus Contraseñas no coinciden");
    } else {

      dispatch(
        updateUserProfile({
          userId: userInfo.id_usu,
          nombre,
          apellido,
          tipo_documento,
          ruc_cliente,
          fecha_nac,
          email,
          telefono
        })
      );
    }
  };

  return (
    <main>
      <div className="container-micuenta">
        <div>
          <h1 className="h1 centrar">Editar cuenta</h1>
          <div className="container-cuenta13">
            <div>
              <form onSubmit={submitHandler}>
             
                  <label className="label1">Nombre</label>
                  <input
                   
                    className="input-cuenta"
                    id="nombre"
                    type="text"
                    placeholder={userInfo.nombre}
                    onChange={(e) => setNombre(e.target.value)}
                  ></input>
                  <hr className="hr" />
                  <label className="label1">Apellido</label>
                  <input
                    className="input-cuenta"
                    id="apellido"
                    type="text"
                    placeholder={userInfo.apellido}
                    onChange={(e) => setApellido(e.target.value)}
                  ></input>

                  <hr className="hr" />

                  <label className="label1">Documento</label>
                  <div className="doc-container">

                 
                   

                    <input
                      className="input-cuenta-doc"
                      id="documento"
                      type="documento"
                      placeholder={userInfo.ruc_cliente}
                      onChange={(e) => setRuc_cliente(e.target.value)}
                      readOnly
                    ></input>
                  </div>
                  <hr className="hr" />
                  <label className="label1">Fecha de nacimiento</label>
                  <input
                    className="input-cuenta"
                    id="fecha_nac"
                    type="text"
                    placeholder={userInfo.fecha_nac}
                    onChange={(e) => setFecha_nac(e.target.value)}
                  ></input>
                  <hr className="hr" />

                  
                  <label className="label1">Correo eléctronico</label>
                  <input
                    className="input-cuenta"
                    id="email"
                    type="email"
                    placeholder={userInfo.email}
                    onChange={(e) => setEmail(e.target.value)}
                  ></input>
                  <hr className="hr" />

                  <label className="label1">Teléfono</label>
                  <input
                    className="input-cuenta"
                    id="telefono"
                    type="documento"
                    placeholder={userInfo.telefono}
                    onChange={(e) => setTelefono(e.target.value)}
                    readOnly
                  ></input>



                 

            
          
                <div className="centrar-botones">
                  <SolidButton txt="Guardar"></SolidButton>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
